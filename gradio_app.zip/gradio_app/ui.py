# -*- coding: utf-8 -*-
"""
CSS（v12モックのスタイルを流用）＋ HTML描画ヘルパー。

Gradioの各ビューは「静的な見た目は gr.HTML でモックのマークアップを再利用」し、
「操作が絡む部分だけ Gradio コンポーネント＋Python関数」で処理する方針。
HTML内から画面遷移したい箇所は、非表示の proxy ボタン（app.py）を JS でクリックして橋渡しする。
"""
import json

import data

# ============================================================
# CSS：モックのスタイル＋Gradio用の上書き
# ============================================================
CSS = r"""
:root{
  --bordeaux-900:#3A1017; --bordeaux-800:#4A1520; --bordeaux-700:#5C1E2B;
  --bordeaux-600:#7A2A3A; --bordeaux-500:#8C3345; --bordeaux-100:#F3E8EA;
  --cream:#FAF8F4; --paper:#FFFFFF; --line:#E9E3DA; --line-soft:#F0EBE3;
  --ink:#2B2624; --ink-soft:#6E6660; --ink-faint:#857C74;
  --ok:#2E7D5B; --ok-bg:#EAF4EF; --warn:#C99A2E; --warn-bg:#FBF4E4;
  --alarm:#B23A48; --alarm-bg:#F9ECEE; --gray-dot:#D4CEC6;
  --radius:10px; --shadow:0 1px 2px rgba(43,20,25,.04), 0 6px 24px rgba(43,20,25,.05);
}

/* ---- Gradio 既定の上書き ---- */
.gradio-container{max-width:100% !important;padding:0 !important;margin:0 !important;
  background:var(--cream);color:var(--ink);
  font-family:'Noto Sans JP',"Hiragino Sans","Yu Gothic",sans-serif;font-size:13px}
.gradio-container .prose *{font-family:inherit}
footer{display:none !important}
/* proxyボタン/テキストボックス：DOMには残しつつ完全に非表示
   （display:noneでもJSの.click()やvalue設定は有効。visible=FalseだとDOMから消えるためCSSで隠す）
   Gradioは単独Textboxを .form ラッパーで包み枠線が残るため、中身が隠し要素のみのformも消す */
.hh-hidden{display:none !important}
.form:has(> .hh-hidden), .form:has(> div > .hh-hidden){display:none !important;border:none !important}
/* Gradioのprose既定色で本文が灰色化するのを打ち消す（proseの色だけ上書き。子要素は継承） */
.hh-content, .hh-content .prose, .hh-content .html-container{color:var(--ink)}
.hh-content strong, .hh-content b{color:inherit;font-weight:600}
/* ボタン要素(.biz-card/.pick-row 等)や見出しがGradioの明色を継承しないよう明示 */
.biz-card, .pick-row{color:var(--ink)}
.page-title, .panel-title, .biz-card-name, .md-h1, .kpi-val, .ov-val,
.ov-subhead, .cd-group-title, .ind-name, .pick-row b, .rag-item b,
.ctx-item b, .alert-head, .step.current{color:var(--ink)}
.md-h2{color:var(--ink)}
.page-meta, .md-meta, .md-src, .md-footnote, .detail-sub, .ind-title{color:var(--ink-faint)}
.ov-label, .impact-line, .start-body, .type-bar .lbl, .ctx-item span{color:var(--ink-soft)}
.check, .file-chip, .cd-sec p, .md-doc li, .md-doc p, .md-tbl td{color:var(--ink)}
.msg.ai .bubble, .msg.user, .ai-summary-body p, .summary p{color:var(--ink)}
.ground-banner{color:var(--ink-soft)}
.msg.user{color:#fff !important}
.cite{color:var(--ink-faint)}
/* 事例ナレッジ基盤・アシスタントの本文コントラスト強化（薄すぎる灰色を解消） */
.tbl td, .cd-sec p, .case-detail-body, .cd-group-title, .cd-sec-label,
.msg.ai .bubble, .rag-item b, .side-panel .panel-title, .ctx-item b{color:var(--ink)}
.rag-item span, .ctx-item span, .suggest button{color:var(--ink-soft)}
.ground-banner b{color:var(--bordeaux-700)}
.step{white-space:nowrap}
/* Gradioのprimaryボタンを阪急マルーンに */
.gradio-container button.primary{background:var(--bordeaux-700) !important;color:#fff !important;
  border:none !important;box-shadow:none !important}
.gradio-container button.primary:hover{filter:brightness(1.12)}
.gradio-container button.secondary:not(.hh-nav):not(.hh-modetab){background:var(--paper) !important;
  border:1px solid var(--line) !important;color:var(--ink-soft) !important;box-shadow:none !important}
/* ビューポート固定レイアウト：外枠は100vh・overflow hidden、本文(.hh-content)だけスクロール。
   これで上部の白スペースを消し、サイドバーを常に全画面高・固定にする。
   ※セレクタはレイアウト直系のみに限定（.wrap等はDropdownの内部要素にも付くため広く指定しない）。 */
html, body, gradio-app, .gradio-container,
.gradio-container > .main,
.gradio-container > .main > .wrap,
.gradio-container > .main > .wrap > .contain,
.gradio-container > .main > .wrap > .contain > .column{
  height:100vh !important;max-height:100vh !important;overflow:hidden !important;
  padding:0 !important;margin:0 !important;gap:0 !important;border:none !important;background:var(--cream)}
.hh-app{gap:0 !important;flex-wrap:nowrap !important;height:100vh !important;
  align-items:stretch !important;overflow:hidden}
.hh-app > *{min-width:0}

/* ---- サイドバー（Gradioボタンで構成）：上から下まで全高・固定 ---- */
.hh-sidebar{background:linear-gradient(180deg,var(--bordeaux-800),var(--bordeaux-900));
  padding:22px 12px !important;gap:2px !important;min-width:212px !important;
  flex:0 0 212px !important;border:none !important;height:100vh;overflow-y:auto}
.hh-brand{display:flex;align-items:center;gap:9px;color:#fff;padding:2px 6px 16px;
  margin-bottom:12px;border-bottom:1px solid rgba(255,255,255,.1)}
.hh-logo{flex:none;width:29px;height:29px;border-radius:8px;display:grid;place-items:center;
  background:linear-gradient(145deg,var(--bordeaux-100),#fff);color:var(--bordeaux-700);
  font-weight:700;font-size:11.5px;letter-spacing:.02em;box-shadow:0 1px 3px rgba(0,0,0,.25)}
.hh-brand-txt{color:#fff;font-weight:600;font-size:12.5px;letter-spacing:.01em;line-height:1.2;white-space:nowrap}
.hh-brand-os{color:var(--warn);margin-left:2px;font-weight:700}
.hh-nav button, button.hh-nav{background:transparent !important;border:none !important;
  color:rgba(255,255,255,.70) !important;font-size:13px !important;letter-spacing:.03em;
  text-align:left !important;display:flex !important;align-items:center !important;gap:10px !important;
  justify-content:flex-start !important;padding:10px 12px !important;
  border-radius:8px !important;box-shadow:none !important;min-height:0 !important;font-weight:400 !important;
  transition:background .15s, color .15s, box-shadow .15s !important}
/* ナビアイコン（CSSマスク。currentColorで着色） */
button.hh-nav::before{content:"";width:15px;height:15px;flex:none;background-color:currentColor;
  -webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-size:contain;mask-size:contain;
  -webkit-mask-position:center;mask-position:center}
.hh-nav button:hover, button.hh-nav:hover{background:rgba(255,255,255,.07) !important;color:#fff !important}
.hh-nav.active button, button.hh-nav.active{background:rgba(255,255,255,.13) !important;color:#fff !important;
  font-weight:500 !important;box-shadow:inset 3px 0 0 var(--warn) !important}
.hh-navspacer{flex:1}
.hh-navsub{border-top:1px solid rgba(255,255,255,.1);margin-top:10px;padding-top:10px}

/* ---- メイン：縦フレックスで本文だけスクロール ---- */
.hh-main{padding:0 !important;background:var(--cream);flex:1 !important;
  height:100vh;display:flex !important;flex-direction:column;overflow:hidden;min-width:0}
.hh-content{padding:34px 40px 56px;flex:1;overflow-y:auto;min-height:0}
/* ビューはクライアントJSで表示切替（.hh-show のみ表示）。初期非表示の内部トグルは .hh-init-hidden。
   display:block にするのは、GradioのColumn(flex-grow:1)がflex親内で縦に伸びるのを防ぐため。 */
.hh-view{max-width:1120px;margin:0 auto;display:none !important}
.hh-view.hh-show{display:block !important}
.hh-init-hidden{display:none}

/* ---- 共通パーツ（モック流用） ---- */
.page-head{display:flex;align-items:baseline;gap:14px;margin-bottom:18px}
.page-title{font-size:17px;font-weight:600;letter-spacing:.02em}
.page-meta{font-size:11px;color:var(--ink-faint)}
.card{background:var(--paper);border:1px solid var(--line);border-radius:var(--radius);box-shadow:var(--shadow)}
.chip{display:inline-flex;align-items:center;gap:5px;font-size:10.5px;padding:2px 8px;border-radius:99px;letter-spacing:.03em;white-space:nowrap}
.chip.alarm{background:var(--alarm-bg);color:var(--alarm)}
.chip.warn{background:var(--warn-bg);color:#9a7620}
.chip.ok{background:var(--ok-bg);color:var(--ok)}
.chip.neutral{background:var(--line-soft);color:var(--ink-soft)}
.hh-btn{display:inline-flex;align-items:center;gap:7px;padding:8px 16px;border-radius:8px;font-size:12.5px;letter-spacing:.03em;transition:filter .15s;cursor:pointer;border:none}
.hh-btn-primary{background:var(--bordeaux-700);color:#fff;font-weight:500}
.hh-btn-primary:hover{filter:brightness(1.12)}
.link{color:var(--bordeaux-600);font-size:12px;font-weight:500;display:inline-flex;align-items:center;gap:4px;cursor:pointer;background:none;border:none;padding:0}
.link:hover{text-decoration:underline}
.dots{display:inline-flex;gap:4px;align-items:center}
.dot{display:inline-block;width:7px;height:7px;border-radius:50%;background:var(--gray-dot);flex:none;vertical-align:middle}
.dot.g{background:var(--ok)} .dot.y{background:var(--warn)} .dot.r{background:var(--alarm)}
.panel-head{display:flex;align-items:center;justify-content:space-between;padding:16px 18px 10px}
.panel-title{font-size:13.5px;font-weight:600;display:flex;align-items:center;gap:8px}
.tbl{width:100%;border-collapse:collapse}
.tbl th{font-size:10.5px;font-weight:500;color:var(--ink-faint);text-align:left;padding:6px 18px;letter-spacing:.05em;border-bottom:1px solid var(--line-soft)}
.tbl td{padding:10px 18px;font-size:12.5px;border-bottom:1px solid var(--line-soft)}
.tbl tr:last-child td{border-bottom:none}
.tbl tbody tr{cursor:pointer}
.tbl tbody tr:hover td{background:var(--cream)}
.tbl tbody tr.active td{background:var(--bordeaux-100)}
.stars{letter-spacing:2px;font-size:12px}

/* KPI */
.kpi-row{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:18px}
.kpi{padding:16px 18px 14px}
.kpi-label{font-size:11px;color:var(--ink-soft);letter-spacing:.05em;display:flex;align-items:center;gap:6px}
.kpi-label .mk{width:7px;height:7px;border-radius:50%;flex:none}
.kpi-val{font-size:26px;font-weight:600;letter-spacing:.01em;margin-top:4px;display:flex;align-items:baseline;gap:5px}
.kpi-val small{font-size:12px;font-weight:400;color:var(--ink-soft)}

/* センシング */
.ai-summary{display:flex;gap:14px;align-items:flex-start;background:var(--bordeaux-100);border-left:3px solid var(--bordeaux-600);border-radius:0 10px 10px 0;padding:15px 18px;margin-bottom:18px}
.ai-summary-tag{flex:none;font-size:10px;font-weight:600;letter-spacing:.08em;color:var(--bordeaux-700);background:rgba(255,255,255,.55);padding:3px 9px;border-radius:99px;margin-top:1px;white-space:nowrap}
.ai-summary-body p{font-size:12.5px;color:var(--ink);line-height:1.7}
.ai-summary-body .link{margin-top:8px}
.sensing-grid{display:grid;grid-template-columns:1.15fr .95fr;gap:16px;align-items:start}
.biz-islands{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:12px;padding:14px 18px 6px}
.biz-card{display:flex;flex-direction:column;gap:10px;border:1px solid var(--line);border-radius:10px;padding:13px 15px;text-align:left;background:var(--paper);transition:border-color .15s,background .15s;cursor:pointer}
.biz-card:hover{border-color:var(--bordeaux-500)}
.biz-card.active{border-color:var(--bordeaux-600);background:var(--bordeaux-100)}
.biz-card.active .biz-card-name{color:var(--bordeaux-700)}
.biz-card-head{display:flex;align-items:center;justify-content:space-between;gap:8px}
.biz-card-name{font-size:12.8px;font-weight:600}
.biz-card-groups{display:grid;gap:7px}
.biz-card-grp{display:flex;align-items:center;gap:9px}
.grp-label{font-size:9px;color:var(--ink-faint);letter-spacing:.03em;width:24px;flex:none}
.biz-legend{padding:2px 18px 14px;font-size:10.5px;color:var(--ink-faint);display:flex;gap:16px}
.biz-legend span{display:flex;align-items:center;gap:5px}
.detail-alert{padding:0 18px 8px}
.alert-head{display:flex;align-items:center;gap:8px;padding:2px 0 6px;font-size:13.5px;font-weight:600}
.alert-head .warn-ic{color:var(--alarm);flex:none}
.impact-line{font-size:12px;color:var(--ink-soft);margin-bottom:10px}
.detail-sub{padding:0 18px 4px;font-size:11px;color:var(--ink-faint)}
.ind-block{padding:0 18px 6px}
.ind-title{font-size:11px;color:var(--ink-faint);letter-spacing:.05em;margin:4px 0 4px;padding-top:10px;border-top:1px solid var(--line-soft)}
.ind-block:first-of-type .ind-title{border-top:none;padding-top:0}
.ind-row{display:flex;align-items:center;gap:8px;padding:6px 0}
.ind-name{flex:1;color:var(--ink);font-size:12px;min-width:0}
.ind-val{width:118px;flex:none;text-align:right;color:var(--ink-soft);font-size:11px;line-height:1.3}
.spark{flex:none;display:block}
/* 島カードのフッター（事業別の監視設定への導線） */
.biz-card-foot{border-top:1px solid var(--line-soft);padding-top:8px;margin-top:2px}
/* 監視設定：スコープ切替タブ */
.scope-tabs{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px}
.scope-tab{border:1px solid var(--line);border-radius:99px;padding:6px 14px;font-size:12px;
  color:var(--ink-soft);background:var(--paper);cursor:pointer;transition:all .15s}
.scope-tab:hover{border-color:var(--bordeaux-500);color:var(--bordeaux-600)}
.scope-tab.active{background:var(--bordeaux-700);border-color:var(--bordeaux-700);color:#fff;font-weight:500}
/* 監視指標の候補リスト（トグル＋インライン閾値設定） */
.sw{flex:none;width:34px;height:19px;border-radius:99px;background:var(--gray-dot);
  position:relative;cursor:pointer;transition:background .15s}
.sw::after{content:"";position:absolute;top:2px;left:2px;width:15px;height:15px;border-radius:50%;
  background:#fff;transition:left .15s;box-shadow:0 1px 2px rgba(0,0,0,.2)}
.sw.on{background:var(--ok)}
.sw.on::after{left:17px}
.cand-sec{font-size:11px;color:var(--ink-faint);letter-spacing:.05em;margin:12px 0 2px;
  padding-bottom:5px;border-bottom:1px solid var(--line-soft)}
.cand-row{display:flex;align-items:center;gap:9px;padding:8px 0;font-size:12.3px;color:var(--ink);
  border-bottom:1px solid var(--line-soft);flex-wrap:wrap}
.cand-row:last-of-type{border-bottom:none}
.cand-row .nm2{width:128px;flex:none;font-weight:500;line-height:1.3}
.cand-row .val{width:118px;flex:none;color:var(--ink-soft);font-size:10.5px;line-height:1.3}
.cand-row input.th{flex:1;min-width:110px;border:1px solid var(--line);border-radius:7px;
  padding:6px 8px;font-size:11px;background:var(--cream);color:var(--ink);outline:none}
.cand-row input.th:focus{border-color:var(--bordeaux-500);background:var(--paper)}
.cand-row select{border:1px solid var(--line);border-radius:7px;padding:6px 4px;font-size:11.5px;
  background:var(--cream);color:var(--ink);outline:none}
.cand-row.off{color:var(--ink-faint)}
.cand-row.off .nm2{color:var(--ink-faint);font-weight:400}
/* 監視設定：左=カタログ（1）／右=事業の監視指標（2）の横並び */
.rules-grid{display:grid;grid-template-columns:1fr 2fr;gap:16px;align-items:start}
@media (max-width:960px){.rules-grid{grid-template-columns:1fr}}
/* 指標カタログ（共通プール）の行：チェック＋名称／API情報の2行コンパクト表示 */
.cat-row{display:flex;align-items:flex-start;gap:9px;padding:7px 0;
  border-bottom:1px solid var(--line-soft);cursor:pointer}
.cat-row:hover{background:var(--cream)}
.cat-row input[type=checkbox]{flex:none;width:15px;height:15px;margin-top:2px;
  accent-color:var(--bordeaux-700);cursor:pointer}
.cat-info{flex:1;min-width:0;display:flex;flex-direction:column;gap:1px}
.cat-nm{font-weight:500;font-size:12.3px;color:var(--ink)}
.cat-meta{font-size:10.5px;color:var(--ink-faint)}
.cat-row .chip{flex:none;margin-top:2px}

/* 診断 */
.import-zones{display:grid;grid-template-columns:1fr 1.2fr;gap:0 28px;padding:4px 18px 16px}
.import-zone{min-width:0}
.import-zone + .import-zone{border-left:1px solid var(--line-soft);padding-left:28px}
.iz-label{font-size:11px;color:var(--ink-faint);letter-spacing:.04em;margin-bottom:8px}
@media (max-width:960px){.import-zones{grid-template-columns:1fr}
  .import-zone + .import-zone{border-left:none;padding-left:0;margin-top:14px}}
.mode-tabs{display:flex;gap:22px;border-bottom:1px solid var(--line);margin-bottom:22px}
.stepper{display:flex;align-items:center;gap:0;margin-bottom:20px}
.step{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--ink-faint)}
.step-num{width:22px;height:22px;border-radius:50%;border:1.5px solid var(--line);display:grid;place-items:center;font-size:11px;background:var(--paper)}
.step.done .step-num,.step.current .step-num{background:var(--bordeaux-700);border-color:var(--bordeaux-700);color:#fff}
.step.current{color:var(--ink);font-weight:600}
.step.done{color:var(--ink-soft)}
.step-line{width:44px;height:1px;background:var(--line);margin:0 10px;flex:none}
.diag-grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;align-items:stretch}
.upload-box{border:1.5px dashed var(--line);border-radius:10px;margin:14px 16px;padding:22px 14px;text-align:center;color:var(--ink-soft)}
.upload-box .doc-ic{width:30px;height:30px;stroke:var(--ink-faint);fill:none;stroke-width:1.4;margin-bottom:8px}
.file-chip{display:flex;align-items:center;justify-content:space-between;margin:0 16px 14px;padding:10px 12px;border:1px solid var(--line-soft);border-radius:8px;font-size:12px;background:var(--cream)}
.check-list{padding:6px 18px 14px;display:grid;gap:9px}
.check{display:flex;align-items:center;gap:9px;font-size:12.5px}
.check .box{width:15px;height:15px;border-radius:4px;background:var(--bordeaux-700);display:grid;place-items:center;flex:none;color:#fff;font-size:10px}
.check.off .box{background:var(--paper);border:1.5px solid var(--line)}
.start-body{padding:14px 18px;font-size:12px;color:var(--ink-soft)}
.note-bar{margin-top:16px;padding:11px 16px;border:1px solid var(--line);border-radius:9px;background:var(--paper);font-size:11.5px;color:var(--ink-soft)}
.run-panel{padding:26px 30px;text-align:center}
.run-steps{max-width:520px;margin:18px auto 0;text-align:left;display:grid;gap:10px}
.run-step{display:flex;align-items:center;gap:12px;font-size:12.5px;color:var(--ink-soft)}
.run-step .st{width:18px;height:18px;border-radius:50%;flex:none;display:grid;place-items:center}
.run-step.done .st{background:var(--ok-bg);color:var(--ok);font-size:11px}
.run-step.now{color:var(--ink);font-weight:500}
.run-step.now .st{border:2px solid var(--bordeaux-500);border-top-color:transparent;animation:hhspin 1s linear infinite}
.run-step.wait .st{border:1.5px solid var(--line)}
@keyframes hhspin{to{transform:rotate(360deg)}}
.progress{height:4px;background:var(--line-soft);border-radius:99px;max-width:520px;margin:22px auto 0;overflow:hidden}
.progress i{display:block;height:100%;background:var(--bordeaux-600);border-radius:99px;transition:width .4s}

/* ブリーフ（簡易Markdown） */
.md-doc{max-width:700px;margin:0 auto;padding-bottom:10px}
.md-eyebrow{font-size:10.5px;letter-spacing:.16em;color:var(--bordeaux-600);font-weight:600}
.md-h1{font-family:'Noto Serif JP',serif;font-size:21px;font-weight:600;line-height:1.55;letter-spacing:.01em;margin-top:8px}
.md-meta{font-size:11.5px;color:var(--ink-faint);margin-top:9px}
.md-h2{font-family:'Noto Serif JP',serif;font-size:14.5px;font-weight:600;margin:24px 0 8px;padding-bottom:7px;border-bottom:1px solid var(--line)}
.md-doc p{font-size:12.8px;color:var(--ink);margin-bottom:6px}
.md-doc ul,.md-doc ol{padding-left:19px;margin:6px 0 10px;display:grid;gap:6px;font-size:12.8px}
.md-doc li{color:var(--ink)}
.md-src{font-size:11px;color:var(--ink-faint);margin:2px 0 4px}
.md-hr{border:none;border-top:1px solid var(--line);margin:26px 0}
.md-tbl{width:100%;border-collapse:collapse;margin:8px 0}
.md-tbl th{font-size:10.5px;color:var(--ink-faint);text-align:left;padding:8px 6px;border-bottom:1px solid var(--line)}
.md-tbl td{padding:9px 6px;font-size:12.5px;border-bottom:1px solid var(--line-soft);vertical-align:top}
.md-footnote{font-size:11px;color:var(--ink-faint);margin-top:28px;padding-top:13px;border-top:1px solid var(--line)}

/* アシスタント */
.assist-modes{display:flex;gap:22px;border-bottom:1px solid var(--line);margin-bottom:20px}
.chat-wrap{display:grid;grid-template-columns:1fr 260px;gap:16px;align-items:start}
.chat{display:flex;flex-direction:column;height:calc(100vh - 250px);min-height:440px;overflow:hidden}
.ground-banner{display:flex;justify-content:space-between;align-items:center;padding:11px 18px;background:var(--bordeaux-100);border-bottom:1px solid var(--line-soft);font-size:11.5px;flex:none}
.ground-banner b{color:var(--bordeaux-700)}
.chat-scroll{flex:1;overflow-y:auto;padding:20px 22px;display:grid;gap:16px;align-content:start}
.msg{max-width:78%;font-size:12.8px;line-height:1.7}
.msg.user{justify-self:end;background:var(--bordeaux-700);color:#fff;border-radius:14px 14px 3px 14px;padding:10px 14px}
.msg.ai{justify-self:start}
.msg.ai .bubble{background:var(--cream);border:1px solid var(--line-soft);border-radius:14px 14px 14px 3px;padding:12px 15px}
.ai-tag{font-size:10px;letter-spacing:.12em;color:var(--bordeaux-500);font-weight:600;margin-bottom:5px}
.rag-list{display:grid;gap:10px;margin-top:10px}
.rag-item{border-left:2px solid var(--line-soft);padding:2px 0 2px 12px}
.rag-item b{font-size:12px;display:flex;gap:8px;align-items:baseline;font-weight:600}
.rag-item b .k{font-family:'Noto Serif JP',serif;color:var(--bordeaux-600)}
.rag-item span{font-size:11px;color:var(--ink-soft);display:block;margin-top:2px}
.cite{font-size:10.5px;color:var(--ink-faint);margin-top:8px;padding-top:7px;border-top:1px dashed var(--line)}
.side-panel .panel-title{font-size:12.5px}
.ctx-item{padding:10px 16px;border-bottom:1px solid var(--line-soft);font-size:11.5px}
.ctx-item:last-child{border-bottom:none}
.ctx-item b{display:block;font-size:12px;margin-bottom:2px}
.ctx-item span{color:var(--ink-soft)}
.suggest{display:grid;gap:6px;padding:10px 14px 14px}
.suggest button{border:1px solid var(--line);border-radius:99px;padding:6px 12px;font-size:11px;color:var(--ink-soft);text-align:left;background:none;cursor:pointer}
.suggest button:hover{border-color:var(--bordeaux-500);color:var(--bordeaux-600)}
.pick-row{display:flex;flex-direction:column;align-items:flex-start;gap:2px;padding:13px 18px;border-top:1px solid var(--line-soft);width:100%;text-align:left;background:none;border-left:none;border-right:none;border-bottom:none;cursor:pointer}
.pick-row:first-child{border-top:none}
.pick-row:hover{background:var(--cream)}
.pick-row b{font-size:12.8px}
.pick-row span{font-size:11px;color:var(--ink-faint)}

/* 事例ナレッジ基盤 */
.case-grid-layout{display:grid;grid-template-columns:1.15fr .95fr;gap:16px;align-items:start}
.ov-grid{display:grid;grid-template-columns:190px 1fr;gap:0 28px;padding:4px 18px 16px;align-items:start}
.ov-stats-col{display:grid;gap:16px;padding-right:24px;border-right:1px solid var(--line-soft)}
.ov-label{font-size:11px;color:var(--ink-soft);letter-spacing:.03em}
.ov-val{font-size:22px;font-weight:600;margin-top:3px}
.ov-val small{font-size:11.5px;font-weight:400;color:var(--ink-soft)}
.ov-subhead{font-size:11px;color:var(--ink-faint);letter-spacing:.04em;margin-bottom:8px}
.type-bar{display:flex;align-items:center;gap:10px;font-size:12px;margin-bottom:9px}
.type-bar:last-child{margin-bottom:0}
.type-bar .lbl{width:112px;flex:none;color:var(--ink-soft)}
.type-bar .bar{flex:1;height:7px;background:var(--line-soft);border-radius:99px;position:relative}
.type-bar .bar i{position:absolute;top:0;left:0;bottom:0;background:var(--bordeaux-500);border-radius:99px}
.type-bar .cnt{width:32px;text-align:right;color:var(--ink-faint);font-size:11px;flex:none}
.case-detail-body{padding:2px 18px 16px}
.cd-row{display:flex;gap:8px;margin-bottom:6px;flex-wrap:wrap}
.cd-group-title{font-size:12.5px;font-weight:600;color:var(--ink);margin-top:16px;padding-top:14px;border-top:1px solid var(--line-soft)}
.cd-sec{margin-top:12px}
.cd-sec-label{font-size:11px;color:var(--bordeaux-600);font-weight:600;letter-spacing:.04em;margin-bottom:4px}
.cd-sec p{font-size:12.3px;color:var(--ink);line-height:1.7}
.cd-links{display:grid;gap:2px;margin-top:6px}
.cd-link{display:flex;align-items:center;gap:7px;font-size:11.8px;color:var(--bordeaux-600);padding:5px 0}
.cd-link svg{width:12px;height:12px;stroke:currentColor;fill:none;stroke-width:1.8;flex:none}

/* モード切替タブ（Gradioボタン） */
.hh-modetab button, button.hh-modetab{background:none !important;border:none !important;
  box-shadow:none !important;color:var(--ink-soft) !important;font-size:13px !important;
  padding:0 2px 10px !important;border-radius:0 !important;min-height:0 !important;
  border-bottom:2px solid transparent !important;font-weight:400 !important}
.hh-modetab.active button, button.hh-modetab.active{color:var(--bordeaux-600) !important;
  font-weight:600 !important;border-bottom:2px solid var(--bordeaux-600) !important}
.hh-mode-row{border-bottom:1px solid var(--line);margin-bottom:20px;gap:22px !important}

/* フォーム系カード内の余白 */
.hh-formcard{padding:0 18px 16px !important}
.case-search-row input, .hh-content input[type=text], .hh-content textarea{
  border:1px solid var(--line);border-radius:9px;background:var(--cream)}
/* 入力欄の文字がGradio既定の明色で読めない問題を解消 */
.hh-content textarea, .hh-content input, .hh-content .wrap-inner,
.gradio-container textarea, .gradio-container input{color:var(--ink) !important}
.hh-content textarea::placeholder, .hh-content input::placeholder{color:var(--ink-faint) !important}
/* Gradioコンポーネント外枠(.block)のダーク背景を消し、ドロップダウン等をクリーム基調に */
.hh-content .block{background:transparent !important;border:none !important;box-shadow:none !important}
.hh-content .wrap-inner, .hh-content .secondary-wrap, .hh-content .dropdown-arrow ~ *{background:transparent !important}
.hh-content .wrap.default{background:var(--cream) !important;border:1px solid var(--line) !important;
  border-radius:9px !important;color:var(--ink) !important}
.hh-content .options{background:var(--paper) !important;color:var(--ink) !important;
  border:1px solid var(--line) !important;box-shadow:var(--shadow) !important}
.hh-content .options .item:hover, .hh-content .options .active{background:var(--bordeaux-100) !important}

/* ===== 可読性チューニング（役員層向けに一段階拡大・コントラスト強化） ===== */
.gradio-container{font-size:13.5px}
.md-doc p, .md-doc ul, .md-doc ol{font-size:13.4px}
.msg{font-size:13.4px}
.tbl td{font-size:13px}
.rag-item b{font-size:12.6px}
.rag-item span{font-size:11.8px}
.cite{font-size:11px}
.md-src{font-size:11.5px}
.page-meta{font-size:11.5px}
.md-meta{font-size:12px}
.chip{font-size:11px}
.ind-val{font-size:11.5px}
.ind-name{font-size:12.5px}
.kpi-label{font-size:11.5px}
.ctx-item{font-size:12px}
.ctx-item b{font-size:12.5px}
.suggest button{font-size:11.5px}
.pick-row span{font-size:11.5px}
.pick-row b{font-size:13.2px}
.page-title{font-size:18px}
.panel-title{font-size:14px}
.md-h1{font-size:22px}
.md-h2{font-size:15.5px}
.biz-card-name{font-size:13px}
.ai-summary-body p{font-size:13px}
.start-body{font-size:12.5px}
.check{font-size:13px}
.note-bar{font-size:12px}

/* ===== トースト（PoC準備中などの通知） ===== */
.hh-toast{position:fixed;bottom:30px;left:50%;transform:translateX(-50%) translateY(8px);
  background:var(--bordeaux-800);color:#fff;padding:11px 20px;border-radius:10px;
  font-size:12.5px;letter-spacing:.02em;box-shadow:0 8px 30px rgba(43,20,25,.35);
  z-index:9999;opacity:0;transition:opacity .25s, transform .25s;pointer-events:none;max-width:80vw}
.hh-toast.show{opacity:1;transform:translateX(-50%) translateY(0)}

/* ===== 通知ベル（右上固定） ===== */
.hh-bell{position:fixed;top:20px;right:24px;z-index:60;width:34px;height:34px;border-radius:50%;
  background:var(--paper);border:1px solid var(--line);display:grid;place-items:center;
  color:var(--ink-soft);box-shadow:var(--shadow);cursor:pointer;transition:color .15s,border-color .15s}
.hh-bell:hover{color:var(--bordeaux-600);border-color:var(--bordeaux-500)}
.hh-bell::after{content:"";position:absolute;top:7px;right:8px;width:7px;height:7px;border-radius:50%;
  background:var(--alarm);border:1.5px solid #fff}
.hh-bell svg{width:16px;height:16px;stroke:currentColor;fill:none;stroke-width:1.6;
  stroke-linecap:round;stroke-linejoin:round}

/* ===== ブリーフのアクションボタン（インライン小型化） ===== */
.hh-inline-actions{max-width:700px;margin:0 auto 4px !important;justify-content:flex-start !important;
  gap:10px !important;flex-wrap:nowrap !important}
.hh-inline-actions > *{flex:0 0 auto !important;min-width:0 !important;width:auto !important}
.hh-inline-actions button{width:auto !important;padding:8px 16px !important;font-size:12.5px !important;
  min-height:0 !important;border-radius:8px !important}

/* ===== 操作フィードバック ===== */
.hh-btn:disabled{opacity:.55;cursor:default;filter:none !important}
.check{cursor:pointer;user-select:none}
.check:hover{color:var(--bordeaux-600)}

@media (max-width:960px){
  .kpi-row{grid-template-columns:1fr 1fr}
  .diag-grid,.chat-wrap,.case-grid-layout,.sensing-grid,.ov-grid{grid-template-columns:1fr}
  /* サイドバーをアイコンレール化（幅64px）。テキストは隠しアイコンのみ表示 */
  .hh-sidebar{min-width:64px !important;flex:0 0 64px !important;padding:18px 8px !important}
  .hh-brand{justify-content:center;padding:0 0 14px;gap:0}
  .hh-brand-txt{display:none}
  button.hh-nav{font-size:0 !important;gap:0 !important;justify-content:center !important;padding:12px 0 !important}
  button.hh-nav::before{width:17px;height:17px}
  .hh-content{padding:24px 18px 40px}
  .hh-bell{top:14px;right:16px}
}
"""

# ---- ナビアイコン（CSSマスク用SVGをdata URIで埋め込み。elem_idごとに割当） ----
from urllib.parse import quote as _q

_NAV_ICONS = {
    "nav-sensing": "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='#000' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'><circle cx='12' cy='12' r='3'/><path d='M5 12a7 7 0 0 1 14 0M2 12a10 10 0 0 1 20 0'/></svg>",
    "nav-diagnosis": "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='#000' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'><path d='M4 19V5m0 14h16M8 15l3-4 3 2 4-6'/></svg>",
    "nav-cases": "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='#000' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'><path d='M12 3 3 7l9 4 9-4-9-4Z'/><path d='M3 12l9 4 9-4M3 17l9 4 9-4'/></svg>",
    "nav-assistant": "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='#000' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'><path d='M21 12a8 8 0 0 1-8 8H5l-2 2V12a8 8 0 0 1 8-8h2a8 8 0 0 1 8 8z'/></svg>",
    "nav-agmqa": "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='#000' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'><path d='M21 12a8 8 0 0 1-8 8H5l-2 2V12a8 8 0 0 1 8-8h2a8 8 0 0 1 8 8Z'/><path d='M10 9a2 2 0 1 1 3 1.7c-.6.4-1 .9-1 1.6v.2M12 15h.01'/></svg>",
    "nav-appmap": "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='#000' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'><circle cx='12' cy='5' r='2'/><circle cx='6' cy='19' r='2'/><circle cx='18' cy='19' r='2'/><path d='M12 7v4M12 11 6 17M12 11l6 6'/></svg>",
    "nav-feedback": "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='#000' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'><path d='M21 12a8 8 0 0 1-8 8H6l-3 3V12a8 8 0 0 1 8-8h1a8 8 0 0 1 8 8Z'/><path d='M12 9v4m-2-2h4'/></svg>",
}
CSS += "\n" + "\n".join(
    f'#{nid}::before{{-webkit-mask-image:url("data:image/svg+xml,{_q(svg, safe="")}");'
    f'mask-image:url("data:image/svg+xml,{_q(svg, safe="")}")}}'
    for nid, svg in _NAV_ICONS.items()
)

STATUS_CHIP = {"ok": ("ok", "正常"), "watch": ("warn", "注視"), "alarm": ("alarm", "要対応")}
DOT_COLOR = {"g": "var(--ok)", "y": "var(--warn)", "r": "var(--alarm)"}


# ============================================================
# 描画ヘルパー
# ============================================================
def spark(values, color):
    """スパークラインSVG（v12 spark() の移植）。"""
    w, h, pad = 54, 16, 2
    vmin, vmax = min(values), max(values)
    rng = (vmax - vmin) or 1
    step = (w - 2 * pad) / (len(values) - 1)
    pts = " ".join(
        f"{pad + i * step:.1f},{h - pad - ((v - vmin) / rng) * (h - 2 * pad):.1f}"
        for i, v in enumerate(values)
    )
    return (f'<svg width="{w}" height="{h}" viewBox="0 0 {w} {h}" class="spark">'
            f'<polyline points="{pts}" fill="none" stroke="{color}" stroke-width="1.6" '
            f'stroke-linecap="round" stroke-linejoin="round"/></svg>')


# ---- センシング：事業の島カード＋詳細（クリックはクライアントJSで完結） ----
def sensing_html():
    """センシングビュー全体。事業ごとの島カード（左）＋詳細カード（右）。
    外部指標の並び順は全島で共通なので、縦に見れば横断比較もできる。"""
    biz_json = json.dumps(data.BUSINESSES, ensure_ascii=False)
    counts = {b["id"]: data.selected_count(b) for b in data.BUSINESSES}
    counts_json = json.dumps(counts, ensure_ascii=False)
    return f"""
<div class="ai-summary">
  <span class="ai-summary-tag">AI要約 ｜ 08:32</span>
  <div class="ai-summary-body">
    <p>現在発火中のアラームは1件です。<strong>阪急阪神ホテルズ</strong>で為替（ドル円157.82円）が閾値（150円）を超過（影響度「高」・未対応）。<strong>阪急阪神エクスプレス</strong>は燃料コストが上昇傾向（+7.8%）で閾値（+8.0%）に接近しており注視中（07/03のアラームは診断済み）。残る電鉄・不動産・百貨店の3事業は正常範囲で推移しています。診断が必要な場合は「診断」画面から手動で実行してください。</p>
  </div>
</div>
<div class="sensing-grid">
  <div class="card">
    <div class="panel-head"><div class="panel-title">主要ビジネス Top5</div>
      <span style="display:flex;align-items:center;gap:12px">
        <span class="chip neutral">事業ごとに監視指標を選択制で設定</span>
        <button class="link" onclick="hhOpenRules('hankyu-rail')">⚙ 監視設定</button>
      </span>
    </div>
    <div class="biz-islands" id="biz-list"></div>
    <div class="biz-legend"><span><i class="dot g"></i>正常</span><span><i class="dot y"></i>注視</span><span><i class="dot r"></i>要対応</span><span style="color:var(--ink-faint)">⚠＝アラーム発火中（未対応）</span></div>
  </div>
  <div class="card" id="biz-detail"></div>
</div>
<script class="hh-run">
(function(){{
  const BUSINESSES = {biz_json};
  const SEL_COUNTS = {counts_json};
  const STATUS_CHIP = {{ok:['ok','正常'], watch:['warn','注視'], alarm:['alarm','要対応']}};
  const DOT_COLOR = {{g:'var(--ok)', y:'var(--warn)', r:'var(--alarm)'}};
  function spark(values, color){{
    const w=54,h=16,pad=2;
    const min=Math.min(...values), max=Math.max(...values);
    const range=(max-min)||1;
    const step=(w-2*pad)/(values.length-1);
    const pts=values.map((v,i)=>`${{(pad+i*step).toFixed(1)}},${{(h-pad-((v-min)/range)*(h-2*pad)).toFixed(1)}}`).join(' ');
    return `<svg width="${{w}}" height="${{h}}" viewBox="0 0 ${{w}} ${{h}}" class="spark"><polyline points="${{pts}}" fill="none" stroke="${{color}}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  }}
  const DOT_LABEL = {{g:'正常', y:'注視', r:'要対応'}};
  function selOnly(list){{ return list.filter(x=>x.sel!==false); }}
  function dotsHtml(bizId, list){{
    return '<span class="dots">'+selOnly(list)
      .map(x=>`<i class="dot ${{x.d}}" title="${{x.n}}：${{x.v}}（${{DOT_LABEL[x.d]}}）"></i>`).join('')+'</span>';
  }}
  function renderIslands(){{
    const wrap = document.getElementById('biz-list');
    if(!wrap) return;
    wrap.innerHTML = BUSINESSES.map(b=>{{
      const chip = STATUS_CHIP[b.status];
      let alm = '';
      if(b.alert){{
        const col = b.alert.impact==='高' ? 'var(--alarm)' : 'var(--warn)';
        alm = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="${{col}}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex:none"><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0zM12 9v4m0 4h.01"/></svg>`;
      }}
      const n = SEL_COUNTS[b.id] || 0;
      return `<div class="biz-card" data-biz="${{b.id}}" onclick="hhSelectBiz('${{b.id}}', true)">
        <div class="biz-card-head"><span class="biz-card-name" style="display:flex;align-items:center;gap:6px">${{alm}}${{b.name}}</span><span class="chip ${{chip[0]}}">${{chip[1]}}</span></div>
        <div class="biz-card-groups">
          <div class="biz-card-grp"><span class="grp-label">外部</span>${{dotsHtml(b.id, b.ext)}}</div>
          <div class="biz-card-grp"><span class="grp-label">内部</span>${{dotsHtml(b.id, b.int)}}</div>
        </div>
        <div class="biz-card-foot"><button class="link" style="font-size:11px"
          onclick="event.stopPropagation();hhOpenRules('${{b.id}}')">⚙ 監視指標 ${{n}}件・閾値を設定 →</button></div>
      </div>`;
    }}).join('');
  }}
  function indRows(bizId, list){{
    return selOnly(list).map(x=>
      `<div class="ind-row"><i class="dot ${{x.d}}" title="${{DOT_LABEL[x.d]}}"></i><span class="ind-name">${{x.n}}</span><span class="ind-val">${{x.v}}</span>${{spark(x.t, DOT_COLOR[x.d])}}</div>`
    ).join('');
  }}
  window.hhSelectBiz = function(id, scroll){{
    const b = BUSINESSES.find(x=>x.id===id);
    document.querySelectorAll('#biz-list .biz-card').forEach(r=>r.classList.toggle('active', r.dataset.biz===id));
    const chip = STATUS_CHIP[b.status];
    let alertHtml = `<div style="padding:14px 18px 4px;font-size:12px;color:var(--ink-soft)">現在、この事業に閾値超過はありません。</div>`;
    if(b.alert){{
      const stars = '★'.repeat(b.alert.starsN)+'☆'.repeat(5-b.alert.starsN);
      const starColor = b.alert.impact==='高' ? 'var(--alarm)' : 'var(--warn)';
      alertHtml = `<div class="detail-alert">
        <div class="alert-head"><svg class="warn-ic" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0zM12 9v4m0 4h.01"/></svg>${{b.alert.title}}<span class="chip alarm">アラーム</span></div>
        <div class="impact-line">影響度：<span class="stars" style="color:${{starColor}}">${{stars}}</span>（${{b.alert.impact}}）　発火日時：${{b.alert.time}}</div>
        <div style="font-size:11px;color:var(--ink-faint);padding-bottom:4px">センシングは通知のみを行います。診断が必要な場合は「診断」画面から手動で実行してください。</div>
      </div>`;
    }}
    document.getElementById('biz-detail').innerHTML = `
      <div class="panel-head"><div class="panel-title">${{b.name}}</div><span class="chip ${{chip[0]}}">${{chip[1]}}</span></div>
      ${{alertHtml}}
      <div class="detail-sub">各指標の直近6期間の推移（スパークライン）</div>
      <div class="ind-block"><div class="ind-title">外部指標</div>${{indRows(b.id, b.ext)}}</div>
      <div class="ind-block"><div class="ind-title">内部KPI</div>${{indRows(b.id, b.int)}}</div>`;
    if(scroll){{
      const el=document.getElementById('biz-detail');
      if(el) el.scrollIntoView({{behavior:'smooth', block:'nearest'}});
    }}
  }};
  renderIslands();
  hhSelectBiz('hotels', false);
}})();
</script>
"""


# ---- 事例ナレッジ基盤 ----
def case_overview_html():
    bars = "".join(
        f'<div class="type-bar"><span class="lbl">{name}</span>'
        f'<span class="bar"><i style="width:{pct}%"></i></span>'
        f'<span class="cnt">{cnt}</span></div>'
        for name, cnt, pct in data.CASE_TYPE_BREAKDOWN
    )
    return f"""
<div class="card" style="margin-bottom:16px">
  <div class="panel-head"><div class="panel-title">ナレッジ基盤の概況</div></div>
  <div class="ov-grid">
    <div class="ov-stats-col">
      <div><div class="ov-label">総事例数</div><div class="ov-val">128 <small>件</small></div></div>
      <div><div class="ov-label">今月の新規登録</div><div class="ov-val">+6 <small>件</small></div></div>
      <div><div class="ov-label">カバー事象タイプ</div><div class="ov-val">6 <small>種</small></div></div>
    </div>
    <div class="ov-types-col">
      <div class="ov-subhead">事象タイプ内訳</div>
      <div class="type-bars">{bars}</div>
    </div>
  </div>
</div>"""


def case_table_html(cases, query=""):
    rows = "".join(
        f'<tr onclick="hhSelectCase({i})" id="case-row-{i}">'
        f'<td>{c["_sim"]}%</td><td>{c["type"]}</td><td>{c["title"]}</td>'
        f'<td>{c["biz"]}</td><td>{c["period"]}</td><td>{c["regDate"]}</td></tr>'
        for i, c in enumerate(cases)
    )
    if not cases:
        rows = '<tr><td colspan="6" style="text-align:center;color:var(--ink-faint);padding:24px">該当する事例が見つかりませんでした</td></tr>'
    # 検索実行が伝わるよう、キャプションにクエリと件数を反映（v12モックと同挙動）
    caption = f'「{query.strip()}」の検索結果 {len(cases)}件' if query.strip() else "類似度順に表示"
    return f"""
<div class="card">
<div class="panel-head"><div class="panel-title">検索事例一覧</div><span class="chip neutral">{caption}</span></div>
<table class="tbl">
  <thead><tr><th>類似度</th><th>タイプ</th><th>タイトル</th><th>関連事業</th><th>時期</th><th>事例登録日</th></tr></thead>
  <tbody>{rows}</tbody>
</table>
</div>
<script class="hh-run">
(function(){{
  window.__CASES = {json.dumps(cases, ensure_ascii=False)};
  window.hhSelectCase = function(i){{
    const c = window.__CASES[i];
    document.querySelectorAll('[id^=case-row-]').forEach(tr=>tr.classList.remove('active'));
    const row = document.getElementById('case-row-'+i); if(row) row.classList.add('active');
    const linkIcon = '<svg viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6M10 14 21 3"/></svg>';
    const links = c.source.split('／').map(s=>`<div class="cd-link">${{linkIcon}}<span>${{s.trim()}}</span></div>`).join('');
    const el = document.getElementById('case-detail-inner');
    if(el) el.innerHTML = `
      <div class="panel-head"><div class="panel-title">${{c.title}}</div><span class="chip neutral">類似度 ${{c._sim}}%</span></div>
      <div class="case-detail-body">
        <div class="cd-row"><span class="chip neutral">${{c.type}}</span><span class="chip neutral">${{c.biz}}</span><span class="chip neutral">${{c.period}}</span><span class="chip neutral">登録：${{c.regDate}}</span></div>
        <div class="cd-sec"><div class="cd-sec-label">概要</div><p>${{c.summary}}</p></div>
        <div class="cd-group-title">事例レポート</div>
        <div class="cd-sec"><div class="cd-sec-label">当時の影響</div><p>${{c.impact}}</p></div>
        <div class="cd-sec"><div class="cd-sec-label">対応</div><p>${{c.response}}</p></div>
        <div class="cd-sec"><div class="cd-sec-label">結果</div><p>${{c.result}}</p></div>
        <div class="cd-group-title">関連リンク</div>
        <div class="cd-links">${{links}}</div>
      </div>`;
  }};
  if(window.__CASES.length) window.hhSelectCase(0);
}})();
</script>"""


def case_detail_shell():
    return '<div class="card" id="case-detail"><div id="case-detail-inner"></div></div>'


# ---- 監視設定（事業別：スコープタブ＋監視指標ON/OFF＋発火ルール） ----
def scope_tabs_html(active_key):
    tabs = "".join(
        f'<button class="scope-tab{" active" if key == active_key else ""}" '
        f'onclick="hhOpenRules(\'{key}\')">{label}</button>'
        for key, label in data.BIZ_SCOPES
    )
    return f'<div class="scope-tabs">{tabs}</div>'


def _selected_row(biz, scope_key, entry):
    """登録済み指標1行：現在値＋閾値・スパンの設定欄＋解除リンク。
    閾値超過時はアプリ内アラーム通知のみ（アクション選択は持たない）。"""
    name = entry["n"]
    thresh, span = data.DEFAULT_THRESH.get(name, ("", "月次"))
    fired = data.FIRED.get((scope_key, name))
    badge = (f'<span class="chip alarm">⚠ {fired}</span>' if fired
             else '<span class="chip neutral">アラーム通知</span>')
    spans = "".join(f'<option{" selected" if s == span else ""}>{s}</option>' for s in data.SPAN_OPTIONS)
    return (f'<div class="cand-row"><span class="nm2">{name}</span>'
            f'<span class="val">{entry["v"]}</span>'
            f'<input class="th" type="text" value="{thresh}" title="発火閾値">'
            f'<select title="監視スパン">{spans}</select>{badge}'
            f'<button class="link" style="font-size:11px" title="監視枠から外す" '
            f'onclick="hhToggleInd(\'{scope_key}|{name}\')">解除</button></div>')


def _catalog_row(biz, name_to_entry, cand):
    """カタログ（共通指標プール）1行：チェックボックス＋名称＋API情報（コンパクト2行表示）。"""
    name = cand["name"]
    entry = name_to_entry.get(name)
    checked = "checked" if (entry and data.is_selected(entry)) else ""
    grp_chip = ('<span class="chip neutral">外部</span>' if cand["group"] == "外部"
                else '<span class="chip" style="background:var(--bordeaux-100);color:var(--bordeaux-700)">内部</span>')
    return (f'<label class="cat-row"><input type="checkbox" data-name="{name}" {checked}>'
            f'<span class="cat-info"><span class="cat-nm">{name}</span>'
            f'<span class="cat-meta">{cand["source"]}｜{cand["freq"]}</span></span>{grp_chip}</label>')


def indicators_html(scope_key):
    """事業別の監視設定：左=指標カタログ（共通プール・幅1）、右=この事業の監視指標（幅2）。
    左でチェック→「選択を確定」→右の監視枠に登録される。"""
    biz = data.find_biz(scope_key) or data.BUSINESSES[0]
    scope_key = biz["id"]
    name_to_entry = {x["n"]: x for x in biz["ext"] + biz["int"]}
    sel_ext = [x for x in biz["ext"] if data.is_selected(x)]
    sel_int = [x for x in biz["int"] if data.is_selected(x)]
    sel_rows = ("".join(_selected_row(biz, scope_key, x) for x in sel_ext + sel_int)
                or '<div style="padding:14px 0;font-size:12px;color:var(--ink-faint)">まだ登録がありません。左のカタログから選択して「選択を確定」を押してください。</div>')
    cat_ext = "".join(_catalog_row(biz, name_to_entry, c) for c in data.CATALOG if c["group"] == "外部")
    cat_int = "".join(_catalog_row(biz, name_to_entry, c) for c in data.CATALOG if c["group"] == "内部")
    n_sel = data.selected_count(biz)
    return f"""
<div class="rules-grid">
  <div class="card">
    <div class="panel-head"><div class="panel-title">指標カタログ（共通プール）</div></div>
    <div style="padding:0 18px 4px;font-size:11px;color:var(--ink-soft)">
      データ取得API接続済み {len(data.CATALOG)}件。チェックして「選択を確定」を押すと、右の監視枠に登録されます。</div>
    <div id="catalog-list" style="padding:2px 18px 4px">
      <div class="cand-sec">外部指標</div>{cat_ext}
      <div class="cand-sec">内部指標（標準3指標）</div>{cat_int}
      <div style="padding:8px 0 2px">
        <button class="link" style="font-size:11px" onclick="hhToast('内部指標の新規登録はPoCでは準備中です（実装ではデータ項目とAPIを紐付けて登録できます）')">＋ 内部指標を登録</button>
      </div>
    </div>
    <div style="padding:6px 18px 18px">
      <button class="hh-btn hh-btn-primary" style="width:100%;justify-content:center"
        onclick="hhApplyCatalog('{scope_key}')">選択を確定 → {biz["name"].replace("阪急阪神", "").replace("阪急", "")}に反映</button>
    </div>
  </div>
  <div class="card">
    <div class="panel-head"><div class="panel-title">この事業の監視指標 — {biz["name"]}</div>
      <span class="chip neutral">登録済み {n_sel} 指標</span></div>
    <div style="padding:0 18px 4px;font-size:11.5px;color:var(--ink-soft)">
      登録済み指標の閾値・スパンを設定します。閾値超過時は<strong>アプリ内アラームで通知のみ</strong>を行い、診断は「診断」画面から手動で実行します。</div>
    <div style="padding:2px 18px 4px">{sel_rows}</div>
    <div style="padding:6px 18px 18px;display:flex;justify-content:flex-end;align-items:center;gap:12px">
      <span style="font-size:11px;color:var(--ink-faint)">閾値の変更は保存で確定します</span>
      <button class="hh-btn hh-btn-primary" onclick="hhToast('{biz["name"]} の閾値設定を保存しました（PoC）')">閾値設定を保存</button>
    </div>
  </div>
</div>"""


# ---- 診断の前提（AI自動抽出テーブル。計画に言及のある指標のみ・手動選択なし） ----
def premises_html():
    rows = ""
    for p in data.PREMISES:
        note_color = {"g": "var(--ok)", "y": "#9a7620", "r": "var(--alarm)"}[p["judge"]]
        judge = f'<i class="dot {p["judge"]}"></i> <span style="color:{note_color};font-size:11px">{p["note"]}</span>'
        src = f'<span style="color:var(--ink-faint)">（{p["src"]}）</span>' if p["src"] != "—" else ""
        rows += (f'<tr><td style="font-weight:600">{p["name"]}</td>'
                 f'<td>{p["plan"]} {src}</td><td>{p["prev"]}</td><td>{p["actual"]}</td>'
                 f'<td>{judge}</td></tr>')
    return f"""
<table class="tbl">
  <thead><tr><th>指標</th><th>計画前提（出典）</th><th>前回計画</th><th>実勢</th><th>判定</th></tr></thead>
  <tbody>{rows}</tbody>
</table>"""


def extract_loading_html():
    """再抽出中のローディング表示。"""
    return """
<div style="padding:28px 18px;text-align:center">
  <div class="run-step now" style="justify-content:center"><span class="st"></span>
  <span style="font-size:12.8px">✦ 計画書を解析し、前提となる外部指標を抽出しています…</span></div>
</div>"""


# ---- 診断：実行パネル（段階的に描画） ----
def run_panel_html(active_idx, done, progress):
    """診断実行パネル。active_idx=現在ステップ、done=Trueで全完了、progress=0..100。"""
    steps = ""
    for i, s in enumerate(data.DIAG_STEPS):
        if done or i < active_idx:
            cls, ic = "done", '<span class="st">✓</span>'
        elif i == active_idx:
            cls, ic = "now", '<span class="st"></span>'
        else:
            cls, ic = "wait", '<span class="st"></span>'
        steps += f'<div class="run-step {cls}">{ic}{s}</div>'
    foot = ""
    if done:
        foot = ('<div style="margin-top:18px"><button class="hh-btn hh-btn-primary" '
                'onclick="showView(\'briefplan\')">'
                '結果（定期診断ブリーフ）を見る →</button></div>')
    title = "診断が完了しました" if done else "診断を実行しています…"
    return f"""
<div class="card run-panel" style="margin-top:16px">
  <div style="font-size:14px;font-weight:600;color:var(--ink)">{title}</div>
  <div style="font-size:11.5px;color:var(--ink-faint);margin-top:3px">阪急阪神ホテルズ 事業計画（2026年度）｜ 定期診断</div>
  <div class="run-steps">{steps}</div>
  <div class="progress"><i style="width:{progress}%"></i></div>
  {foot}
</div>"""


# ---- アシスタント：チャット描画 ----
def chat_html(messages, height="calc(100vh - 320px)"):
    """messages: [{'role':'ai'|'user','html':...}]。ai_tag付きのバブルを並べる。"""
    body = ""
    for m in messages:
        if m["role"] == "user":
            body += f'<div class="msg user">{m["html"]}</div>'
        else:
            body += f'<div class="msg ai"><div class="ai-tag">AI経営診断アプリ</div><div class="bubble">{m["html"]}</div></div>'
    return (f'<div class="chat-scroll" style="height:{height};border:1px solid var(--line);'
            f'border-radius:10px;background:var(--paper)">{body}</div>'
            '<script class="hh-run">(function(){var s=document.querySelectorAll(".chat-scroll");'
            'if(s.length){var e=s[s.length-1];e.scrollTop=e.scrollHeight;}})();</script>')


# 深掘りモードの初期会話（fx0705はデモ用にリッチな例示会話、他論点はウェルカムのみ）
DEEPDIVE_INIT = [
    {"role": "ai", "html": data.DEEPDIVE_TOPICS["fx0705"]["welcome"]},
    {"role": "user", "html": "ホテル事業の打ち手について、単価戦略とヘッジ強化のどちらを優先すべきか比較して。"},
    {"role": "ai", "html": data.assistant_reply("単価戦略とヘッジ強化のどちらを優先すべきか比較", "fx0705")},
]


def deepdive_init(topic_key):
    """論点ごとの初期会話。fx0705のみ例示付き、他はウェルカムメッセージから開始。"""
    if topic_key == "fx0705":
        return list(DEEPDIVE_INIT)
    return [{"role": "ai", "html": data.DEEPDIVE_TOPICS[topic_key]["welcome"]}]


def deep_side_html(topic_key):
    """深掘りモードのサイドパネル（グラウンディングコンテキスト＋よく使う依頼）。論点連動。"""
    t = data.DEEPDIVE_TOPICS[topic_key]
    ctx = "".join(f'<div class="ctx-item"><b>{k}</b><span>{v}</span></div>' for k, v in t["ctx"])
    # 依頼チップはクリックで入力欄に転記（hhFill）。実際に使える操作にする。
    sug = "".join(f'<button onclick="hhFill(\'deep-input\', \'{s}\')">{s}</button>' for s in t["suggests"])
    return f"""
<div class="card side-panel">
  <div class="panel-head"><div class="panel-title">グラウンディング中のコンテキスト</div></div>
  {ctx}
  <div class="panel-head" style="padding-top:6px"><div class="panel-title">この論点でよく使う依頼</div></div>
  <div class="suggest">{sug}</div>
</div>"""

# 一般質問モードの初期会話
OPEN_INIT = [
    {"role": "ai", "html": "経営ブリーフ・事例ナレッジ基盤・全事業体のセンシング指標を横断して回答します。何を調べますか。"},
    {"role": "user", "html": "直近1ヶ月に発火した臨時診断を、影響度の高いものから事業体別に一覧化して。"},
    {"role": "ai", "html": (
        "直近1ヶ月で発火した臨時診断は3件です。影響度順に整理しました。"
        '<div class="rag-list">'
        '<div class="rag-item"><b><span class="k">1</span>円安の閾値超過（07/05）</b><span>ホテル・百貨店にプラス、鉄道原価にマイナス。影響度：高</span></div>'
        '<div class="rag-item"><b><span class="k">2</span>燃料コスト上昇の継続監視（07/03）</b><span>国際輸送（エクスプレス）の採算を圧迫。影響度：中</span></div>'
        '<div class="rag-item"><b><span class="k">3</span>大型イベント延期の影響試算（06/28）</b><span>鉄道・ホテルの需要下振れ。影響度：中</span></div>'
        '</div>'
        '<div class="cite">根拠：センシングログ32件／経営ブリーフ5件（2026年6月〜7月）／事例ナレッジ基盤</div>')},
]


# ---- 静的ビュー（ブリーフ本文・アプリ構造・株主総会QA） ----
BRIEF_HEAD = """
<div class="md-eyebrow">臨時影響分析レポート ｜ 経営ブリーフ</div>
<h1 class="md-h1">円安の閾値超過（157.82円）——ホテル・流通・国際輸送への影響見立て</h1>
<div class="md-meta">アラーム検知：2026/07/05 08:15（センシング通知）　診断実行：08:52（手動）　生成：08:56　対象：グループ5事業</div>
"""

BRIEF_BODY = """
<div class="md-doc" style="max-width:700px;margin:8px auto 0">
  <h2 class="md-h2">概要と結論</h2>
  <ul>
    <li>為替（ドル円）が157.82円まで上昇し、監視閾値（150.00円）を超過した。過去60営業日レンジの上限を明確に突破。</li>
    <li>ホテル・百貨店はインバウンド需要増でプラス方向、鉄道・ホテルは輸入コスト増でマイナス方向。方向は分かれるが、費用増側の確度がより高い。</li>
    <li>推奨は「①単価戦略の前倒し」を主軸に、確度の高い費用増には「②ヘッジ比率の見直し」を並行して着手する。</li>
  </ul>
  <p><strong>確信度：中</strong>（5事業体・複数指標の一次データに基づく初期分析）</p>
  <hr class="md-hr">
  <h2 class="md-h2">1. 何が起きたか</h2>
  <p>ドル円レートが157.82円まで上昇し、監視閾値（150.00円）を明確に超過した。過去60営業日レンジの上限を突破し、20営業日で+4.2%のペースで推移している。日米金利差の拡大観測が主因とみられる。</p>
  <div class="md-src">出典：日銀公表レート（2026/07/05 08:00）／ 主要経済紙 報道3件 ／ 監視ルール #FX-01</div>
  <h2 class="md-h2">2. どう波及するか</h2>
  <ul>
    <li>円安進行 → インバウンド需要の増加 → ホテル・百貨店の客室単価／免税売上の押上げ</li>
    <li>円安進行 → 輸入コスト（エネルギー・食材・資材）の増加 → 鉄道・ホテルの動力費・原価を圧迫</li>
  </ul>
  <h2 class="md-h2">3. 影響の程度（方向 × オーダー × 確度）</h2>
  <table class="md-tbl">
    <thead><tr><th>事業</th><th>方向</th><th>大きさのオーダー（対計画）</th><th>確度</th></tr></thead>
    <tbody>
      <tr><td>ホテル事業</td><td><span class="chip ok">プラス</span></td><td>売上 +1〜4% 程度</td><td>中（インバウンド比率に依存）</td></tr>
      <tr><td>百貨店（流通）</td><td><span class="chip ok">プラス</span></td><td>免税売上 +数%〜10%台</td><td>中</td></tr>
      <tr><td>国際輸送（エクスプレス）</td><td><span class="chip warn">中立〜マイナス</span></td><td>採算 −数% 程度</td><td>低（建値通貨ミックス次第）</td></tr>
      <tr><td>鉄道（動力費）</td><td><span class="chip alarm">マイナス</span></td><td>費用 +1% 未満〜数%</td><td>高（燃調契約から推定可能）</td></tr>
    </tbody>
  </table>
  <div class="md-src">根拠：各社直近KPI（マスキング済）× 事業構造マップの因果パス × 類似局面の実績レンジ。値は幅で示し、確定値は各社決算値による。点推定はしない。</div>
  <h2 class="md-h2">4. 過去の類似局面</h2>
  <ul>
    <li><strong>2022年 急速な円安局面（〜151円）</strong>（類似度：高）— ホテル・百貨店はインバウンド回復と重なり増収。エネルギーコスト増が鉄道・ホテル原価を圧迫し、価格改定とヘッジ強化で対応した企業が多い。<div class="md-src">出典：主要私鉄・百貨店各社 有価証券報告書／決算説明資料（2022–23年度）</div></li>
    <li><strong>2023–24年 インバウンド急回復期</strong>（類似度：中）— 免税売上・客室単価が想定を上回るペースで伸長。供給制約（人手・客室）がボトルネックとなり、単価戦略への切替が有効に機能した。<div class="md-src">出典：観光庁統計／業界紙DB／シンクタンクレポート</div></li>
  </ul>
  <p><button class="link" onclick="showView('cases')">事例ナレッジ基盤で関連事例をさらに見る →</button></p>
  <h2 class="md-h2">5. 取りうる打ち手</h2>
  <ol>
    <li><strong>インバウンド単価戦略の前倒し</strong>（ホテル・百貨店）— 得：上振れの最大化、供給制約下でも増益余地／失：国内客の価格感応度、ブランド毀損リスク</li>
    <li><strong>エネルギー・調達コストのヘッジ比率見直し</strong>（鉄道・ホテル）— 得：下振れの限定、予見可能性の向上／失：円高反転時の機会損失、ヘッジコスト</li>
    <li><strong>静観しモニタリング強化</strong>（160円を追加閾値に設定）— 得：拙速な意思決定の回避／失：対応が後手に回るリスク</li>
  </ol>
  <h2 class="md-h2">6. 今後モニタリングすべき指標</h2>
  <p>ドル円 160円ライン／日米金利差／訪日外客数（月次）／輸入エネルギー価格／客室ADR・免税売上（週次）</p>

  <div class="md-footnote">本ブリーフは公開・マスキング済データに基づく参考情報であり、数値の正確性を保証するものではありません。</div>
  <div style="margin-top:10px"><button class="link" onclick="showView('diagnosis')">← 診断ワークスペースに戻る</button></div>
</div>
"""

# ---- 定期診断ブリーフ（計画ベース：前提乖離＋過去計画差分・整合性が主役） ----
PLAN_BRIEF_HEAD = """
<div class="md-eyebrow">定期診断レポート ｜ 経営ブリーフ</div>
<h1 class="md-h1">中期経営計画2026-2028 定期診断——前提の乖離と過去計画との差分・整合性</h1>
<div class="md-meta">実行：2026/07/05 09:30（手動・診断ワークスペース）　照合：過去計画5件　生成：09:36　対象：グループ5事業</div>
"""

PLAN_BRIEF_BODY = """
<div class="md-doc" style="max-width:700px;margin:8px auto 0">
  <h2 class="md-h2">概要と結論</h2>
  <ul>
    <li>AIが計画書から抽出した前提5項目のうち、実勢との乖離が「大」2項目（為替・エネルギー価格）、「中」1項目（人件費）。</li>
    <li>過去計画5件との照合で差分12箇所・トーン変化3箇所を検出。事業利益目標はCAGR +5%→+7%へ上方修正（根拠記載あり）。</li>
    <li>総合評価：計画の骨格は維持可能。ただし為替・エネルギー前提の感応度分析と、下振れシナリオの明文化を推奨する。</li>
  </ul>
  <p><strong>確信度：中</strong>（計画書全文＋過去計画5件＋センシング実勢値に基づく点検）</p>
  <hr class="md-hr">
  <h2 class="md-h2">1. 前提と実勢の乖離（外部整合性）</h2>
  <table class="md-tbl">
    <thead><tr><th>指標</th><th>計画前提（出典）</th><th>実勢</th><th>判定</th></tr></thead>
    <tbody>
      <tr><td>為替（ドル円）</td><td>145円（P.12）</td><td>157.82円</td><td><span class="chip alarm">乖離 +8.8%</span></td></tr>
      <tr><td>原材料・エネルギー価格</td><td>横ばい（P.20）</td><td>+8.4%</td><td><span class="chip alarm">乖離 大</span></td></tr>
      <tr><td>人件費・賃金</td><td>+2.5%／年（P.18）</td><td>+3.1%</td><td><span class="chip warn">上振れ</span></td></tr>
      <tr><td>訪日外客数</td><td>年 +8%（P.9）</td><td>+12%</td><td><span class="chip ok">上振れ（好機）</span></td></tr>
      <tr><td>金利（国内）</td><td>0.3%以下（P.14）</td><td>0.26%</td><td><span class="chip ok">範囲内</span></td></tr>
    </tbody>
  </table>
  <div class="md-src">前提は ✦AIが計画書から自動抽出（P.9〜P.20）。実勢はセンシングの監視値（2026/07/05時点）。</div>

  <h2 class="md-h2">2. 過去計画との差分・整合性</h2>
  <table class="md-tbl">
    <thead><tr><th>項目</th><th>前回計画（2023-2025中計）</th><th>今回計画（2026-2028中計）</th><th>評価</th></tr></thead>
    <tbody>
      <tr><td>為替前提</td><td>140円／ドル</td><td>145円／ドル</td><td><span class="chip alarm">要確認</span> 実勢157.82円は今回前提も超過</td></tr>
      <tr><td>事業利益目標</td><td>CAGR +5%</td><td>CAGR +7%</td><td><span class="chip warn">上方修正</span> 根拠の記載あり（P.6）</td></tr>
      <tr><td>エネルギー価格前提</td><td>記載なし</td><td>横ばい</td><td><span class="chip alarm">要確認</span> 実勢 +8.4% と乖離</td></tr>
      <tr><td>インバウンド依存リスク</td><td>記載なし</td><td>新規記載（P.22）</td><td><span class="chip ok">整合</span> センシング体制と符合</td></tr>
    </tbody>
  </table>
  <ul>
    <li><strong>トーン変化：</strong>需要見通しの記述が「保守的」→「強気」に変化（総括 P.3）。上振れ前提への依存度が上昇しており、下振れ時の代替シナリオの明記が望ましい。</li>
    <li><strong>整合性チェック：</strong>照合6項目中、整合 4 ／ 要確認 2（為替前提・エネルギー価格前提）。</li>
  </ul>
  <div class="md-src">照合対象：事業計画アーカイブ 5件（2020-2022中計／2023-2025中計／単年度計画 2024-2026）｜ 差分検出 12箇所・トーン変化 3箇所</div>

  <h2 class="md-h2">3. リスクの洗い出し</h2>
  <ul>
    <li>為替の感応度分析が未記載。150円台が継続した場合の事業利益インパクトが計画から読めない。</li>
    <li>エネルギー価格の調達ヘッジ方針が明文化されておらず、コスト増が鉄道・ホテルの原価を直撃する構造。</li>
    <li>人件費の上振れ（+3.1%）が3期連続。計画の+2.5%前提を継続する根拠が弱い。</li>
    <li>インバウンド需要への依存度が上昇。訪日客数の反転時に売上・単価の両面で下振れするリスク。</li>
  </ul>

  <h2 class="md-h2">4. 過去の類似局面</h2>
  <ul>
    <li><strong>2022年 急速な円安局面（〜151円）</strong>（類似度：高）— 前提乖離を放置した企業は期中の下方修正を余儀なくされ、感応度分析を開示した企業は市場の信認を維持した。<div class="md-src">出典：主要私鉄・百貨店各社 有価証券報告書（2022–23年度）</div></li>
  </ul>
  <p><button class="link" onclick="showView('cases')">事例ナレッジ基盤で関連事例をさらに見る →</button></p>

  <h2 class="md-h2">5. 提言（取りうる打ち手）</h2>
  <ol>
    <li><strong>為替・エネルギーの感応度分析を計画に追記</strong> — ±10円／±10%での事業利益レンジを明示し、前提乖離時の判断基準を持つ</li>
    <li><strong>下振れシナリオの明文化</strong> — 需要反転時の投資抑制・コスト調整の発動条件を定義</li>
    <li><strong>四半期レビューでの前提再点検</strong> — センシングの監視指標と計画前提を紐付け、乖離が閾値を超えたら計画側を見直す運用へ</li>
  </ol>

  <h2 class="md-h2">6. 今後モニタリングすべき指標</h2>
  <p>ドル円 150円ライン（計画前提比）／輸入エネルギー価格／賃金統計（毎月勤労統計）／訪日外客数（月次）——いずれもセンシングの監視設定済み</p>

  <div class="md-footnote">本ブリーフは公開・マスキング済データに基づく参考情報であり、数値の正確性を保証するものではありません。</div>
  <div style="margin-top:10px"><button class="link" onclick="showView('diagnosis')">← 診断ワークスペースに戻る</button></div>
</div>
"""

APPMAP_HTML = """
<div class="md-doc">
  <div class="md-eyebrow">システムドキュメント</div>
  <h1 class="md-h1">アプリの構造</h1>
  <div class="md-meta">経営者の3つの問いに答える4機能構成</div>
  <h2 class="md-h2">経営者の3つの問い</h2>
  <ol>
    <li><strong>気づく</strong> — 何が起きた／起きうるのか。計画とのズレ、外部環境の変化、突発事象に気づきたい。</li>
    <li><strong>見極める</strong> — うちにどれくらい効くのか。どの事業に、どの経路で、どの程度の影響か。</li>
    <li><strong>打ち手を選ぶ</strong> — どうすればいいのか。取りうる選択肢とそれぞれの得失、過去の対処法。</li>
  </ol>
  <h2 class="md-h2">4つの機能</h2>
  <table class="md-tbl">
    <thead><tr><th>機能</th><th>役割</th><th>答える問い</th></tr></thead>
    <tbody>
      <tr><td>⓪ 常時センシング</td><td>KPI・外部指標の定常監視。閾値超過はアプリ内アラームで通知（診断は行わない）</td><td>気づく</td></tr>
      <tr><td>① 定期診断</td><td>事業計画の整合性・論理性・リスクをHD横断で精査（手動実行）</td><td>気づく・見極める・打ち手すべて</td></tr>
      <tr><td>② 臨時診断</td><td>急変・突発事象の影響度をシナリオ分析（アラームを受けて手動実行）</td><td>見極める・打ち手</td></tr>
      <tr><td>③ 事例ナレッジ基盤</td><td>類似事例を①②に自動供給する共有基盤</td><td>見極める・打ち手の確からしさを支える</td></tr>
    </tbody>
  </table>
  <h2 class="md-h2">機能間の関係性</h2>
  <ul>
    <li>①定期診断と②臨時診断は診断パイプラインがほぼ同一。トリガー（定期／イベント）と入力が違うだけ。</li>
    <li>⓪常時センシングの役割は<strong>アラーム通知まで</strong>。診断はすべてユーザーが「診断」画面から手動で実行する（自動発火はしない）。</li>
    <li>③事例ナレッジ基盤は①②の両方に過去の類似局面を供給する。単独タブとしての価値は持たせず、診断結果に自動で添えられる。</li>
  </ul>
  <h2 class="md-h2">設計理念</h2>
  <ul>
    <li>全機能の出力は「経営ブリーフ」1枚の型に固定する。</li>
    <li>影響度は点推定しない。方向 × 大きさのオーダー × 確度の幅で示す。</li>
    <li>UIは増やさない。センシング＝気づく（アラーム）、診断＝動く（手動実行）と責務を分け、画面間の遷移を最小にする。</li>
  </ul>
</div>
"""

AGM_HTML = """
<div class="page-head"><h1 class="page-title">株主総会QAサポート</h1><span class="page-meta">近日公開</span></div>
<div class="card" style="padding:50px 30px;text-align:center">
  <div style="font-size:12.8px;color:var(--ink-soft);max-width:440px;margin:0 auto;line-height:1.8">
    株主総会での想定質問に対する回答案の作成を支援する機能を準備中です。過去の想定問答・IR資料・事例ナレッジ基盤と連携し、質問への回答ドラフトを提示する予定です。
  </div>
</div>
"""


# ---- フィードバック ----
def fb_chip(status):
    m = {"notyet": ("alarm", "未着手"), "consider": ("neutral", "検討中"),
         "inprogress": ("warn", "対応中"), "done": ("ok", "反映済み")}[status]
    return f'<span class="chip {m[0]}">{m[1]}</span>'


def feedback_table_html(feedback):
    rows = "".join(
        f'<tr><td>{f["cat"]}</td><td>{f["text"]}</td><td>{f["who"]}</td>'
        f'<td>{fb_chip(f["status"])}</td><td>{f["date"]}</td></tr>'
        for f in feedback
    )
    return f"""
<div class="panel-head"><div class="panel-title">フィードバック一覧</div></div>
<table class="tbl">
  <thead><tr><th>カテゴリ</th><th>内容</th><th>投稿者</th><th>状態</th><th>日付</th></tr></thead>
  <tbody>{rows}</tbody>
</table>"""


def kpi_row_html(total, notyet, inprogress, done):
    return f"""
<div class="kpi-row">
  <div class="card kpi"><div class="kpi-label">総件数</div><div class="kpi-val">{total} <small>件</small></div></div>
  <div class="card kpi"><div class="kpi-label"><span class="mk" style="background:var(--alarm)"></span>未着手</div><div class="kpi-val">{notyet} <small>件</small></div></div>
  <div class="card kpi"><div class="kpi-label"><span class="mk" style="background:var(--warn)"></span>対応中</div><div class="kpi-val">{inprogress} <small>件</small></div></div>
  <div class="card kpi"><div class="kpi-label"><span class="mk" style="background:var(--ok)"></span>反映済み</div><div class="kpi-val">{done} <small>件</small></div></div>
</div>"""
