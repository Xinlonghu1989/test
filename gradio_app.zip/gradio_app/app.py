# -*- coding: utf-8 -*-
"""
HHグループ AI経営診断アプリ ｜ Gradioモック（v12 UIモックの再現）

構成（左サイドバー＋8ビュー。Gradioの表示/非表示切替でSPA風に見せる）：
  センシング / 診断（定期・シナリオ）/ 経営ブリーフ / 事例ナレッジ基盤 /
  AIアシスタント（深掘り・任意質問）/ 株主総会QA / アプリの構造 / フィードバックボード

擬似バックエンドは data.py の関数（診断実行・事例検索・FB投稿・チャット応答）。
HTML内リンクからの画面遷移は、非表示 proxy ボタンを JS でクリックして橋渡しする。
"""
import html
import os
import time

import gradio as gr

import data
import ui

def page_head(title, meta):
    return f'<div class="page-head"><h1 class="page-title">{title}</h1><span class="page-meta">{meta}</span></div>'


# ---- 擬似操作：診断実行（5ステップを段階的に描画） ----
def run_diagnosis():
    n = len(data.DIAG_STEPS)
    for i in range(n):
        prog = max(12, int(i / n * 100))
        yield ui.run_panel_html(i, False, prog)
        time.sleep(0.9)
    yield ui.run_panel_html(n, True, 100)


# ---- 擬似操作：前提の再抽出（AIが計画書を読み直す体のアニメ） ----
def run_extract():
    yield ui.extract_loading_html()
    time.sleep(1.4)
    gr.Info("計画書から前提5項目を抽出しました")
    yield ui.premises_html()


# ---- 擬似操作：監視設定（事業別・候補リストから選択） ----
def open_rules(scope_key):
    """監視設定ページを指定スコープで描画。島カードの⚙やタブ切替から呼ばれる。"""
    key = scope_key if scope_key in data.SCOPE_LABEL else data.BIZ_SCOPES[0][0]
    return ui.scope_tabs_html(key), ui.indicators_html(key), key


def do_toggle_ind(arg):
    """'事業id|指標名' を受けて監視指標の選択をON/OFF。設定パネルと島カードの両方を更新。"""
    biz_id, _, name = (arg or "").partition("|")
    if biz_id and name:
        data.toggle_select(biz_id, name)
    return ui.indicators_html(biz_id), ui.sensing_html()


def do_apply_catalog(arg):
    """'事業id|指標名,指標名,…' を受けてカタログの選択を監視枠へ一括反映。"""
    biz_id, _, joined = (arg or "").partition("|")
    names = [n for n in joined.split(",") if n]
    biz = data.find_biz(biz_id)
    if biz:
        data.apply_catalog(biz_id, names)
        gr.Info(f"{biz['name']} の監視枠に {len(names)} 指標を登録しました")
    return ui.indicators_html(biz_id), ui.sensing_html()


# ---- 擬似操作：事例検索 ----
def do_search(query):
    return ui.case_table_html(data.search_cases(query), query)


# ---- 擬似操作：フィードバック投稿 ----
def submit_fb(category, text):
    if not (text or "").strip():
        gr.Warning("内容を入力してください")
        return (ui.kpi_row_html(*data.feedback_counts()),
                ui.feedback_table_html(data.FEEDBACK), text)
    data.add_feedback(category, text)
    gr.Info("フィードバックを投稿しました")
    return (ui.kpi_row_html(*data.feedback_counts()),
            ui.feedback_table_html(data.FEEDBACK), "")


# ---- 擬似操作：チャット応答 ----
def send_deep(text, state, topic):
    if not (text or "").strip():
        return ui.chat_html(state), state, ""
    state = state + [
        {"role": "user", "html": html.escape(text)},
        {"role": "ai", "html": data.assistant_reply(text, topic)},
    ]
    return ui.chat_html(state), state, ""


def send_open(text, state):
    if not (text or "").strip():
        return ui.chat_html(state), state, ""
    state = state + [
        {"role": "user", "html": html.escape(text)},
        {"role": "ai", "html": data.assistant_reply(text, None)},
    ]
    return ui.chat_html(state), state, ""


def ground_banner_html(topic_key):
    t = data.DEEPDIVE_TOPICS[topic_key]
    return (f'<div class="ground-banner"><span>グラウンディング中：<b id="ground-banner-title">{t["title"]}</b></span>'
            f'<button class="link" onclick="unground()">論点を変更</button></div>')


# ============================================================
# 画面組み立て
# ============================================================
with gr.Blocks(title="HHグループ AI経営診断アプリ", fill_width=True) as demo:

    with gr.Row(elem_classes="hh-app"):
        # ---------- サイドバー ----------
        with gr.Column(elem_classes="hh-sidebar", scale=0, min_width=200):
            gr.HTML('<div class="hh-brand"><span class="hh-logo">HH</span>'
                    '<span class="hh-brand-txt">AI経営診断アプリ</span></div>')
            nav_sensing = gr.Button("センシング", elem_classes="hh-nav", elem_id="nav-sensing")
            nav_diag = gr.Button("診断", elem_classes="hh-nav", elem_id="nav-diagnosis")
            nav_cases = gr.Button("事例ナレッジ基盤", elem_classes="hh-nav", elem_id="nav-cases")
            nav_assist = gr.Button("AIアシスタント", elem_classes="hh-nav", elem_id="nav-assistant")
            nav_agm = gr.Button("株主総会QAサポート", elem_classes="hh-nav", elem_id="nav-agmqa")
            gr.HTML('<div class="hh-navspacer"></div>')
            nav_appmap = gr.Button("アプリの構造", elem_classes=["hh-nav", "hh-navsub"], elem_id="nav-appmap")
            nav_feedback = gr.Button("フィードバックボード", elem_classes="hh-nav", elem_id="nav-feedback")

        # ---------- メイン ----------
        with gr.Column(elem_classes="hh-main"):
            with gr.Column(elem_classes="hh-content"):
                # 画面遷移はすべてクライアントJS（showView等）で行う。
                # Python発火が必要な操作のみ、HTML→Pythonの橋渡し用に隠しボタンを置く：
                #   proxy-run          … 診断実行（ジェネレータで段階描画）
                #   proxy-topic-*      … 深掘り論点の切替（バナー・会話・コンテキストを差替え）
                proxy_run = gr.Button("", elem_classes="hh-hidden", elem_id="proxy-run")
                proxy_topic_fx = gr.Button("", elem_classes="hh-hidden", elem_id="proxy-topic-fx")
                proxy_topic_fuel = gr.Button("", elem_classes="hh-hidden", elem_id="proxy-topic-fuel")
                proxy_topic_event = gr.Button("", elem_classes="hh-hidden", elem_id="proxy-topic-event")
                proxy_topic_plan = gr.Button("", elem_classes="hh-hidden", elem_id="proxy-topic-plan")
                proxy_extract = gr.Button("", elem_classes="hh-hidden", elem_id="proxy-extract")
                # カタログの選択確定：JSがチェック済み指標名を書き込み→クリックでPython反映
                catalog_arg = gr.Textbox("", elem_classes="hh-hidden", elem_id="catalog-arg")
                proxy_catalog_apply = gr.Button("", elem_classes="hh-hidden", elem_id="proxy-catalog-apply")
                # 監視設定ページを事業スコープ指定で開く／指標の選択ON/OFF
                rules_open_arg = gr.Textbox("", elem_classes="hh-hidden", elem_id="rules-open-arg")
                proxy_rules_open = gr.Button("", elem_classes="hh-hidden", elem_id="proxy-rules-open")
                ind_arg = gr.Textbox("", elem_classes="hh-hidden", elem_id="ind-arg")
                proxy_ind_toggle = gr.Button("", elem_classes="hh-hidden", elem_id="proxy-ind-toggle")

                # 通知ベル（右上固定）。センシングの発火状況への導線。
                gr.HTML('<button class="hh-bell" title="通知" '
                        'onclick="showView(\'sensing\');hhToast(\'未対応アラーム1件：円安が閾値を超過（ホテルズ・07/05 08:15）\')">'
                        '<svg viewBox="0 0 24 24"><path d="M18 9a6 6 0 1 0-12 0c0 6-2 7-2 7h16s-2-1-2-7M10.3 20a2 2 0 0 0 3.4 0"/></svg>'
                        '</button>')

                # ===== ビュー：センシング =====
                with gr.Column(elem_classes=["hh-view", "hh-show"], elem_id="view-sensing") as v_sensing:
                    gr.HTML(page_head("センシングダッシュボード", "最終更新：2026/07/05 08:30 ｜ 日次自動実行"))
                    # 指標ON/OFFやルール件数の変更を反映できるよう参照を保持
                    sensing_comp = gr.HTML(ui.sensing_html())

                # ===== ビュー：診断 =====
                with gr.Column(elem_classes="hh-view", elem_id="view-diagnosis") as v_diag:
                    gr.HTML(page_head("診断ワークスペース", "定期・臨時とも同一パイプライン ｜ トリガーのみ異なる"))
                    with gr.Row(elem_classes="hh-mode-row"):
                        btn_mode_plan = gr.Button("定期診断（Plan Review）", elem_classes=["hh-modetab", "active"])
                        btn_mode_scn = gr.Button("シナリオ診断（Scenario）", elem_classes="hh-modetab")
                    with gr.Column(elem_id="mode-plan") as mode_plan:
                        past_chips = "".join(
                            f'<span class="chip neutral">{p}</span>' for p in data.PAST_PLANS[:2]
                        ) + f'<span class="chip neutral">単年度計画 ×{len(data.PAST_PLANS) - 2}</span>'
                        gr.HTML(f"""
<div class="stepper">
  <div class="step current"><span class="step-num">1</span>インポート</div><span class="step-line"></span>
  <div class="step"><span class="step-num">2</span>AI前提抽出</div><span class="step-line"></span>
  <div class="step"><span class="step-num">3</span>診断実行</div><span class="step-line"></span>
  <div class="step"><span class="step-num">4</span>結果</div>
</div>
<div class="card" style="margin-bottom:16px">
  <div class="panel-head"><div class="panel-title">インポート</div><span class="chip neutral">今回計画＋過去計画を自動連動</span></div>
  <div class="import-zones">
    <div class="import-zone">
      <div class="iz-label">今回の計画</div>
      <div class="file-chip" style="margin:0"><span>中期経営計画2026-2028.pdf　<span style="color:var(--ink-faint)">2.4 MB</span></span><span style="color:var(--ok)">✓ 読込済み</span></div>
      <button class="link" style="margin-top:8px" onclick="hhToast('PoCではサンプル計画（中期経営計画2026-2028.pdf）を使用します')">別のファイルを選択</button>
    </div>
    <div class="import-zone">
      <div class="iz-label">過去計画フォルダ（差分・整合性の照合対象）</div>
      <div style="font-size:12.5px;color:var(--ink);display:flex;align-items:center;gap:7px">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="var(--ink-soft)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
        /経営企画/事業計画アーカイブ
        <button class="link" onclick="hhToast('フォルダ指定はPoCでは準備中です（サンプルの5件を照合します）')">変更</button>
      </div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px">{past_chips}
        <span class="chip ok">{len(data.PAST_PLANS)}件を照合対象に連動済み</span></div>
    </div>
  </div>
</div>
""")
                        with gr.Column(elem_classes="card", elem_id="premise-card"):
                            gr.HTML("""
<div class="panel-head"><div class="panel-title">診断の前提</div>
  <span style="display:flex;align-items:center;gap:12px">
    <span class="chip" style="background:var(--bordeaux-100);color:var(--bordeaux-700)">✦ AIが計画書から自動抽出 ｜ 5項目</span>
    <button class="link" onclick="hhClick('proxy-extract')">再抽出</button>
  </span>
</div>
<div style="padding:0 18px 8px;font-size:11.5px;color:var(--ink-soft)">計画書に言及のある前提指標をAIが自動で洗い出し、実勢・前回計画と突き合わせています（手動での指標選択は不要です）。</div>
""")
                            premise_table = gr.HTML(ui.premises_html())
                            gr.HTML("""
<div style="padding:4px 18px 18px;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">
  <button class="link" onclick="hhToast('手動追加はPoCでは準備中です')">＋ 手動で指標を追加</button>
  <button class="hh-btn hh-btn-primary" onclick="hhStartRun(this)">診断を開始する</button>
</div>
""")
                        gr.HTML("""
<div class="note-bar">ⓘ 診断観点：① 外部整合性（前提×実勢の乖離） ② 内部論理性（過去計画5件との差分・トーン変化） ③ リスク抽出 ④ 類似事例照会 ⑤ ブリーフ生成。影響度は「方向 × 大きさのオーダー × 確度」の幅で示し、点推定は行いません。</div>
""")
                        run_output = gr.HTML()
                    with gr.Column(elem_id="mode-scenario", elem_classes="hh-init-hidden") as mode_scenario:
                        gr.HTML("""
<div class="card" style="margin-bottom:16px">
  <div class="panel-head"><div class="panel-title">イベントを指定して影響を診断</div><span class="chip neutral">手動実行</span></div>
  <div style="padding:4px 18px 16px">
    <div style="display:flex;gap:10px">
      <input type="text" style="flex:1;padding:11px 14px;font:inherit;outline:none" value="ドル円が160円を超えて推移した場合、グループ各事業への影響を見たい">
      <button class="hh-btn hh-btn-primary" onclick="showView('brief')">影響を診断する</button>
    </div>
    <div style="font-size:11px;color:var(--ink-faint);margin-top:8px">センシングは閾値超過をアラームで通知するのみです。診断はこの画面から手動で実行します。</div>
  </div>
</div>
<div class="card">
  <div class="panel-head"><div class="panel-title">センシングからのアラーム</div><span class="chip alarm">未対応 1件</span></div>
  <table class="tbl">
    <thead><tr><th>発火日時</th><th>アラーム</th><th>影響度</th><th>状態</th><th></th></tr></thead>
    <tbody>
      <tr><td>07/05 08:15</td><td>円安が閾値を超過（157.82円）｜ ホテルズ</td><td><span class="stars" style="color:var(--alarm)">★★★★★</span></td><td><span class="chip alarm">未対応</span></td><td><button class="link" onclick="showView('brief')">この内容で診断を実行 →</button></td></tr>
      <tr style="color:var(--ink-faint)"><td>07/03 14:20</td><td>燃料コスト上昇（+9.1%・当時）｜ エクスプレス</td><td><span class="stars" style="color:var(--warn)">★★★☆☆</span></td><td><span class="chip ok">診断済み</span></td><td><button class="link" onclick="hhToast('PoCでは円安レポートのみ閲覧できます')">レポート →</button></td></tr>
      <tr style="color:var(--ink-faint)"><td>06/28 10:40</td><td>大型イベント延期の影響試算 ｜ 鉄道・ホテル</td><td><span class="stars" style="color:var(--warn)">★★★☆☆</span></td><td><span class="chip ok">診断済み</span></td><td><button class="link" onclick="hhToast('PoCでは円安レポートのみ閲覧できます')">レポート →</button></td></tr>
    </tbody>
  </table>
  <div style="padding:0 18px 14px;font-size:11px;color:var(--ink-faint)">「診断を実行」を押すと、アラーム内容を前提条件としてシナリオ診断を開始します（自動では実行されません）。</div>
</div>
""")

                # ===== ビュー：経営ブリーフ（臨時診断＝アラーム起点・手動実行） =====
                with gr.Column(elem_classes="hh-view", elem_id="view-brief") as v_brief:
                    gr.HTML('<div class="md-doc">' + ui.BRIEF_HEAD + '</div>')
                    with gr.Row(elem_classes="hh-inline-actions"):
                        brief_deep_btn = gr.Button("この話題を深掘りする", variant="primary")
                        brief_pdf_btn = gr.Button("PDF出力")
                    gr.HTML(ui.BRIEF_BODY)

                # ===== ビュー：経営ブリーフ（定期診断＝計画ベース） =====
                with gr.Column(elem_classes="hh-view", elem_id="view-briefplan") as v_briefplan:
                    gr.HTML('<div class="md-doc">' + ui.PLAN_BRIEF_HEAD + '</div>')
                    with gr.Row(elem_classes="hh-inline-actions"):
                        brief_plan_deep_btn = gr.Button("この話題を深掘りする", variant="primary")
                        brief_plan_pdf_btn = gr.Button("PDF出力")
                    gr.HTML(ui.PLAN_BRIEF_BODY)

                # ===== ビュー：事例ナレッジ基盤 =====
                with gr.Column(elem_classes="hh-view", elem_id="view-cases") as v_cases:
                    gr.HTML(page_head("事例ナレッジ基盤",
                                      "類似事例の検索・閲覧 ｜ 他社事例・業界動向など外部事例を中心に収集し、①②診断に自動供給"))
                    gr.HTML(ui.case_overview_html())
                    with gr.Column(elem_classes="card"):
                        gr.HTML('<div class="panel-head"><div class="panel-title">類似度検索</div></div>')
                        with gr.Row(elem_classes="hh-formcard"):
                            case_in = gr.Textbox(value="円安 ホテル 影響", show_label=False,
                                                 placeholder="例：円安 ホテル 影響", scale=6, container=False)
                            case_btn = gr.Button("検索", variant="primary", scale=1)
                    with gr.Row(equal_height=False):
                        with gr.Column(scale=6):
                            case_table = gr.HTML(ui.case_table_html(data.search_cases("円安 ホテル 影響"), "円安 ホテル 影響"))
                        with gr.Column(scale=5):
                            gr.HTML(ui.case_detail_shell())

                # ===== ビュー：AIアシスタント =====
                with gr.Column(elem_classes="hh-view", elem_id="view-assistant") as v_assist:
                    gr.HTML(page_head("AIアシスタント", "論点の深掘り／任意質問の2モード"))
                    with gr.Row(elem_classes="hh-mode-row"):
                        btn_amode_deep = gr.Button("論点の深掘り", elem_classes=["hh-modetab", "active"])
                        btn_amode_open = gr.Button("任意質問", elem_classes="hh-modetab")

                    # --- 深掘りモード ---
                    with gr.Column(elem_id="amode-deep") as amode_deep:
                        with gr.Column(elem_id="ground-picker") as ground_picker:
                            gr.HTML("""
<div class="card">
  <div class="panel-head"><div class="panel-title">深掘りする論点を選択</div></div>
  <div style="padding:0 18px 16px;font-size:11.5px;color:var(--ink-soft)">経営ブリーフの「この話題を深掘りする」から開始するか、最近のレポートから選択してください。選択した論点にAIの回答が固定され、根拠のブレを防ぎます。</div>
  <button class="pick-row" onclick="openDeep('定期診断（中計2026-2028）');hhClick('proxy-topic-plan')"><b>定期診断（中期経営計画2026-2028）</b><span>2026/07/05 生成 ｜ 前提乖離・過去計画差分</span></button>
  <button class="pick-row" onclick="openDeep('円安の閾値超過（157.82円）');hhClick('proxy-topic-fx')"><b>円安の閾値超過（157.82円）</b><span>2026/07/05 生成 ｜ ホテル・流通・国際輸送</span></button>
  <button class="pick-row" onclick="openDeep('燃料コスト上昇の継続監視');hhClick('proxy-topic-fuel')"><b>燃料コスト上昇の継続監視</b><span>2026/07/03 生成 ｜ 阪急阪神エクスプレス</span></button>
  <button class="pick-row" onclick="openDeep('大型イベント延期の影響試算');hhClick('proxy-topic-event')"><b>大型イベント延期の影響試算</b><span>2026/06/28 生成 ｜ 鉄道・ホテル</span></button>
</div>
""")
                        with gr.Column(elem_id="ground-chat", elem_classes="hh-init-hidden") as ground_chat:
                            ground_banner = gr.HTML(ground_banner_html("fx0705"))
                            with gr.Row(equal_height=False):
                                with gr.Column(scale=7):
                                    deep_chat = gr.HTML(ui.chat_html(ui.DEEPDIVE_INIT))
                                    with gr.Row(elem_classes="hh-formcard"):
                                        deep_in = gr.Textbox(show_label=False, container=False, scale=8,
                                                             elem_id="deep-input",
                                                             placeholder="この論点について質問する…（例：3案を採る場合の会議アジェンダ候補を出して）")
                                        deep_send = gr.Button("送信", variant="primary", scale=1)
                                with gr.Column(scale=3, min_width=240):
                                    # 論点連動のサイドパネル（コンテキスト＋依頼チップ）。論点切替で差替え
                                    deep_side = gr.HTML(ui.deep_side_html("fx0705"))

                    # --- 任意質問モード ---
                    with gr.Column(elem_id="amode-open", elem_classes="hh-init-hidden") as amode_open:
                        with gr.Row(equal_height=False):
                            with gr.Column(scale=7):
                                open_chat = gr.HTML(ui.chat_html(ui.OPEN_INIT))
                                with gr.Row(elem_classes="hh-formcard"):
                                    open_in = gr.Textbox(show_label=False, container=False, scale=8,
                                                         elem_id="open-input",
                                                         placeholder="全社データベースに質問する…（例：事例ナレッジ基盤から類似度80%以上の為替事例を出して）")
                                    open_send = gr.Button("送信", variant="primary", scale=1)
                            with gr.Column(scale=3, min_width=240):
                                gr.HTML("""
<div class="card side-panel">
  <div class="panel-head"><div class="panel-title">検索対象</div></div>
  <div class="ctx-item"><b>経営ブリーフ</b><span>24件（全期間）</span></div>
  <div class="ctx-item"><b>事例ナレッジ基盤</b><span>128件</span></div>
  <div class="ctx-item"><b>センシング指標</b><span>全5事業・42指標</span></div>
  <div class="panel-head" style="padding-top:6px"><div class="panel-title">よく使う依頼</div></div>
  <div class="suggest">
    <button onclick="hhFill('open-input','先月のアラートを事業体別に集計して')">先月のアラートを事業体別に集計</button>
    <button onclick="hhFill('open-input','事例ナレッジ基盤から類似度80%以上の事例を検索して')">事例ナレッジ基盤から類似度80%以上を検索</button>
    <button onclick="hhFill('open-input','全事業のKPI異常を横断チェックして')">全事業のKPI異常を横断チェック</button>
    <button onclick="hhFill('open-input','中期経営計画との整合性を横断確認して')">中期経営計画との整合性を横断確認</button>
  </div>
</div>
""")

                # ===== ビュー：株主総会QA =====
                with gr.Column(elem_classes="hh-view", elem_id="view-agmqa") as v_agm:
                    gr.HTML(ui.AGM_HTML)

                # ===== ビュー：アプリの構造 =====
                with gr.Column(elem_classes="hh-view", elem_id="view-appmap") as v_appmap:
                    gr.HTML(ui.APPMAP_HTML)

                # ===== ビュー：監視設定（ナビ非表示。島カードの⚙から事業別に遷移） =====
                with gr.Column(elem_classes="hh-view", elem_id="view-rules") as v_rules:
                    gr.HTML('<div style="margin-bottom:6px"><button class="link" onclick="showView(\'sensing\')">← センシングダッシュボードに戻る</button></div>')
                    gr.HTML(page_head("監視設定", "指標候補から事業ごとに選択し、閾値も個別に設定 ｜ 選んだ指標が島カードのドットになります"))
                    scope_tabs = gr.HTML(ui.scope_tabs_html("hankyu-rail"))
                    # 左=カタログ（共通プール）／右=事業の監視指標 の2カード構成はHTML内で組む
                    indicators_panel = gr.HTML(ui.indicators_html("hankyu-rail"))

                # ===== ビュー：フィードバックボード =====
                with gr.Column(elem_classes="hh-view", elem_id="view-feedback") as v_feedback:
                    gr.HTML(page_head("フィードバックボード", "PoCの改善提案・気づいた点を共有する場です"))
                    fb_kpi = gr.HTML(ui.kpi_row_html(*data.feedback_counts()))
                    with gr.Column(elem_classes="card"):
                        gr.HTML('<div class="panel-head"><div class="panel-title">新規投稿</div></div>')
                        with gr.Column(elem_classes="hh-formcard"):
                            fb_cat = gr.Dropdown(["UI/UX", "データ・指標", "診断ロジック", "その他"],
                                                 value="UI/UX", show_label=False, container=False)
                            fb_text = gr.Textbox(show_label=False, lines=3, container=False,
                                                 placeholder="改善提案や気づいた点を入力してください")
                            fb_submit = gr.Button("投稿する", variant="primary")
                    with gr.Column(elem_classes="card"):
                        fb_table = gr.HTML(ui.feedback_table_html(data.FEEDBACK))

    # gr.HTML内に注入した<script class="hh-run">を更新後に実行するJS。
    RUN_JS = "() => { setTimeout(function(){ window.hhRun && window.hhRun(); }, 30); }"

    # ---- 画面遷移・モード切替はすべてクライアントJSで行う（1クリックで確実／サーバ往復なし） ----
    # サイドバーのナビ
    nav_sensing.click(None, None, None, js="() => showView('sensing')")
    nav_diag.click(None, None, None, js="() => showView('diagnosis')")
    nav_cases.click(None, None, None, js="() => showView('cases')")
    nav_assist.click(None, None, None, js="() => showView('assistant')")
    nav_agm.click(None, None, None, js="() => showView('agmqa')")
    nav_appmap.click(None, None, None, js="() => showView('appmap')")
    nav_feedback.click(None, None, None, js="() => showView('feedback')")

    # 診断モード切替（定期／シナリオ）
    btn_mode_plan.click(None, None, None, js="() => showDiagMode('plan')")
    btn_mode_scn.click(None, None, None, js="() => showDiagMode('scenario')")

    # アシスタントのモード切替（深掘り／任意質問）
    btn_amode_deep.click(None, None, None, js="() => showAmode('deep')")
    btn_amode_open.click(None, None, None, js="() => showAmode('open')")

    # 診断実行（擬似・段階描画）。HTMLボタン→hhStartRun→proxy_run→Python。
    proxy_run.click(run_diagnosis, None, run_output)

    # 前提の再抽出（ローディング→テーブル再表示）
    proxy_extract.click(run_extract, None, premise_table)

    # 監視設定：スコープ切替・指標ON/OFF（閾値保存はダミートースト）
    rules_scope = gr.State("hankyu-rail")
    proxy_rules_open.click(open_rules, rules_open_arg,
                           [scope_tabs, indicators_panel, rules_scope]
                           ).then(None, None, None, js=RUN_JS)
    proxy_ind_toggle.click(do_toggle_ind, ind_arg,
                           [indicators_panel, sensing_comp]).then(None, None, None, js=RUN_JS)
    proxy_catalog_apply.click(do_apply_catalog, catalog_arg,
                              [indicators_panel, sensing_comp]).then(None, None, None, js=RUN_JS)

    # ---- 深掘り：論点の切替（バナー・初期会話・コンテキスト・会話状態を論点連動で差替え） ----
    deep_state = gr.State(list(ui.DEEPDIVE_INIT))
    open_state = gr.State(list(ui.OPEN_INIT))
    topic_state = gr.State("fx0705")

    def set_topic(key):
        init = ui.deepdive_init(key)
        return (ground_banner_html(key), ui.chat_html(init), ui.deep_side_html(key),
                key, list(init), "")

    topic_outputs = [ground_banner, deep_chat, deep_side, topic_state, deep_state, deep_in]
    for _btn, _key in [(proxy_topic_fx, "fx0705"), (proxy_topic_fuel, "fuel"),
                       (proxy_topic_event, "event0628"), (proxy_topic_plan, "plan2026")]:
        _btn.click(lambda k=_key: set_topic(k), None, topic_outputs).then(None, None, None, js=RUN_JS)

    # ブリーフ：深掘りへ（画面遷移はJS即時＋論点データをサーバで反映）／PDF出力
    brief_deep_btn.click(lambda: set_topic("fx0705"), None, topic_outputs,
                         js="() => openDeep('円安の閾値超過（157.82円）')").then(None, None, None, js=RUN_JS)
    brief_pdf_btn.click(lambda: gr.Info("PDF出力（PoCではダミー）"), None, None)
    brief_plan_deep_btn.click(lambda: set_topic("plan2026"), None, topic_outputs,
                              js="() => openDeep('定期診断（中計2026-2028）')").then(None, None, None, js=RUN_JS)
    brief_plan_pdf_btn.click(lambda: gr.Info("PDF出力（PoCではダミー）"), None, None)

    # チャット送信（深掘りは論点にグラウンディング）
    deep_send.click(send_deep, [deep_in, deep_state, topic_state], [deep_chat, deep_state, deep_in]).then(None, None, None, js=RUN_JS)
    deep_in.submit(send_deep, [deep_in, deep_state, topic_state], [deep_chat, deep_state, deep_in]).then(None, None, None, js=RUN_JS)
    open_send.click(send_open, [open_in, open_state], [open_chat, open_state, open_in]).then(None, None, None, js=RUN_JS)
    open_in.submit(send_open, [open_in, open_state], [open_chat, open_state, open_in]).then(None, None, None, js=RUN_JS)

    # 事例検索
    case_btn.click(do_search, case_in, case_table).then(None, None, None, js=RUN_JS)
    case_in.submit(do_search, case_in, case_table).then(None, None, None, js=RUN_JS)

    # フィードバック投稿
    fb_submit.click(submit_fb, [fb_cat, fb_text], [fb_kpi, fb_table, fb_text])

    # 初期化JS：画面遷移・モード切替をクライアント側で完結させる関数群を定義。
    #  - showView(name)     ：8ビューの表示切替（サイドバーactiveも更新）
    #  - showDiagMode(m)    ：診断の 定期/シナリオ 切替
    #  - showAmode(m)       ：アシスタントの 深掘り/任意 切替
    #  - openDeep(title)/unground()：深掘りの picker↔chat 切替
    #  - hhRun()            ：gr.HTML内の<script class="hh-run">を実行（innerHTML挿入では走らないため）
    #  - hhClick(id)        ：隠しGradioボタン(proxy-run)をクリックしてPython発火
    demo.load(None, None, None, js="""
() => {
  // ダークテーマを無効化（ライト基調に固定）。入力・ドロップダウン等の暗色を解消。
  document.documentElement.classList.remove('dark');
  document.body.classList.remove('dark');
  window.hhClick = function(id){
    var e = document.getElementById(id); if(!e) return;
    var b = (e.tagName === 'BUTTON') ? e : e.querySelector('button'); if(b) b.click();
  };
  // トースト（PoC準備中・通知など）。連続呼び出しは置き換え。
  window.hhToast = function(msg){
    var t = document.querySelector('.hh-toast');
    if(!t){ t = document.createElement('div'); t.className = 'hh-toast'; document.body.appendChild(t); }
    t.textContent = msg;
    clearTimeout(t._tm1); clearTimeout(t._tm2);
    requestAnimationFrame(function(){ t.classList.add('show'); });
    t._tm1 = setTimeout(function(){ t.classList.remove('show'); }, 2600);
    t._tm2 = setTimeout(function(){ t.remove(); }, 3000);
  };
  // Gradio Textboxへ値を転記（依頼チップ→入力欄）。inputイベントでsvelte状態も同期。
  window.hhFill = function(id, text){
    var wrap = document.getElementById(id); if(!wrap) return;
    var input = wrap.querySelector('textarea, input'); if(!input) return;
    input.value = text;
    input.dispatchEvent(new Event('input', {bubbles: true}));
    input.focus();
  };
  // 設定チェックボックスのトグル（見た目のみ・PoC）
  window.hhToggleCheck = function(el){
    el.classList.toggle('off');
    var box = el.querySelector('.box');
    if(box) box.textContent = el.classList.contains('off') ? '' : '✓';
  };
  // 監視設定ページを事業スコープ指定で開く（島カードの⚙／タブ切替から）
  window.hhOpenRules = function(key){
    showView('rules');
    hhFill('rules-open-arg', key);
    setTimeout(function(){ hhClick('proxy-rules-open'); }, 60);
  };
  // 監視指標のON/OFF切替（'事業id|指標名'）
  window.hhToggleInd = function(arg){
    hhFill('ind-arg', arg);
    setTimeout(function(){ hhClick('proxy-ind-toggle'); }, 60);
  };
  // カタログのチェック状態を収集して確定（事業の監視枠へ一括反映）
  window.hhApplyCatalog = function(bizId){
    var names = [...document.querySelectorAll('#catalog-list input[type=checkbox]:checked')]
      .map(function(c){ return c.dataset.name; });
    hhFill('catalog-arg', bizId + '|' + names.join(','));
    setTimeout(function(){ hhClick('proxy-catalog-apply'); }, 60);
  };
  // 診断ステッパー（1→4）の進行表示
  window.hhStepper = function(state){
    var steps = document.querySelectorAll('#view-diagnosis .stepper .step');
    if(steps.length < 4) return;
    function set(i, cls){ steps[i].classList.remove('done','current'); if(cls) steps[i].classList.add(cls); }
    if(state === 'run'){ set(0,'done'); set(1,'done'); set(2,'current'); set(3,null); }
    else if(state === 'done'){ set(0,'done'); set(1,'done'); set(2,'done'); set(3,'current'); }
    else { set(0,'current'); set(1,null); set(2,null); set(3,null); }
  };
  // 診断実行：ボタンを即「実行中」化（連打防止）→ パネルへ自動スクロール → 完了でステッパー更新
  window.hhStartRun = function(btn){
    if(btn.dataset.running) return;
    btn.dataset.running = '1'; btn.disabled = true;
    var orig = btn.textContent; btn.textContent = '診断を実行中…';
    hhClick('proxy-run');
    hhStepper('run');
    var tries = 0, scrolled = false;
    var iv = setInterval(function(){
      tries++;
      var rp = document.querySelector('.run-panel');
      if(rp && !scrolled){ scrolled = true; rp.scrollIntoView({behavior:'smooth', block:'center'}); }
      var steps = rp ? rp.querySelectorAll('.run-step') : [];
      var doneAll = steps.length > 0 && rp.querySelectorAll('.run-step.done').length === steps.length;
      if(doneAll || tries > 120){
        clearInterval(iv);
        if(doneAll) hhStepper('done');
        btn.disabled = false; btn.textContent = orig; delete btn.dataset.running;
      }
    }, 300);
  };
  window.hhRun = function(){
    document.querySelectorAll('script.hh-run').forEach(function(old){
      if(old.dataset.ran) return;
      old.dataset.ran = '1';
      var s = document.createElement('script');
      s.textContent = old.textContent;
      old.parentNode.replaceChild(s, old);
    });
  };
  function show(id, on){ var e=document.getElementById(id); if(e) e.style.display = on ? 'block' : 'none'; }
  window.showView = function(name){
    ['sensing','diagnosis','brief','briefplan','cases','assistant','agmqa','appmap','feedback','rules']
      .forEach(function(v){ var el=document.getElementById('view-'+v); if(el) el.classList.toggle('hh-show', v===name); });
    var navKey = (name==='brief'||name==='briefplan') ? 'diagnosis' : (name==='rules') ? 'sensing' : name;
    document.querySelectorAll('.hh-nav').forEach(function(b){ b.classList.remove('active'); });
    var nb=document.getElementById('nav-'+navKey); if(nb) nb.classList.add('active');
    if(window.hhRun) window.hhRun();
    var c=document.querySelector('.hh-content'); if(c) c.scrollTop=0;
  };
  window.showDiagMode = function(m){
    show('mode-plan', m==='plan'); show('mode-scenario', m==='scenario');
    var tabs=document.querySelectorAll('#view-diagnosis .hh-modetab');
    if(tabs[0]) tabs[0].classList.toggle('active', m==='plan');
    if(tabs[1]) tabs[1].classList.toggle('active', m==='scenario');
  };
  window.showAmode = function(m){
    show('amode-deep', m==='deep'); show('amode-open', m==='open');
    var tabs=document.querySelectorAll('#view-assistant .hh-modetab');
    if(tabs[0]) tabs[0].classList.toggle('active', m==='deep');
    if(tabs[1]) tabs[1].classList.toggle('active', m==='open');
  };
  window.openDeep = function(title){
    showView('assistant'); showAmode('deep');
    show('ground-picker', false); show('ground-chat', true);
    var t=document.getElementById('ground-banner-title'); if(t && title) t.textContent = title;
  };
  window.unground = function(){ show('ground-picker', true); show('ground-chat', false); };

  // 初期状態
  showView('sensing'); showDiagMode('plan'); showAmode('deep'); window.unground();
  setTimeout(window.hhRun, 60);
}
""")


if __name__ == "__main__":
    demo.queue().launch(
        theme=gr.themes.Base(font=[gr.themes.GoogleFont("Noto Sans JP"), "sans-serif"]),
        css=ui.CSS,
        favicon_path=os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "favicon.svg"),
        server_name=os.getenv("GRADIO_SERVER_NAME", "127.0.0.1"),
        server_port=int(os.getenv("GRADIO_SERVER_PORT", "7870")),
        inbrowser=False,
    )
